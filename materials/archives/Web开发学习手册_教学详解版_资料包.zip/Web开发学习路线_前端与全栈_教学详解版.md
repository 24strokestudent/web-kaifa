# Web 开发学习教材与实战清单（前端 / 全栈双路线 · 知识详解版）
> 2026 年 10 月 · 社团教学版 · 针对零基础或有 C++ 基础的同学 · 建议每周 5 天、每天 1–2 小时

## 如何选择路线

| 路线 | 学习区间 | 能做什么 | 不要求什么 |
| --- | --- | --- | --- |
| 共同基础 | 第 1–8 周 | 静态站、交互网页、读 API、Git 与静态部署 | 暂不需要框架、数据库 |
| 仅前端 | 共同基础 + 第 9–20 周 | React/Vue 前端、交互界面、调用 API、测试与上线 | 不必自建后端和数据库 |
| 全栈 | 共同基础 + 第 9–24 周 | 前端 + 自建 API + SQL + 鉴权 + 部署 | 不要求同时学多个前后端框架 |

**重要边界**：前端可以调用现成 API，但不能只靠隐藏按钮实现可靠权限；全栈要多掌握服务器、数据持久化与安全。周数仅用于排课，不是能力保证。

## 建议学习方式
- 每天：20 分钟理解概念、40–70 分钟自己写、10–20 分钟调试与记录。
- 每周：至少 1 个可运行的小成果；不看教程独立重写一个小变体。
- 每个阶段：完成知识勾选 + 实战项目 + 验收，才算通过。
- AI 当老师/代码审查员/有边界的助手，不把“AI 说跑通了”当成测试证据。

## 第一、二周：逐日任务与配套知识讲义

> **课程衔接**：第 8–14 天先接触 Grid、媒体查询和手机适配；第 3–4 周再处理更复杂的响应式布局与调试，不是重新从零学一遍。

### Day 01｜认识 Web + 创建第一张 HTML
**知识要点**
- [ ] 浏览器、HTML 文件与网页的关系
- [ ] doctype、head、body、title、charset
- [ ] 标题 h1/h2、段落 p、基本标签嵌套
**动手任务**：创建 web-study/index.html，写出社团标题、简介、两个板块并在浏览器打开。
**验收**：能说清 title 和 h1 的区别；不看示例写出基础 HTML 骨架。
- [ ] Day 01 当日完成并记录练习结果
**容易踩坑**：不要把文件误存为 .html.txt。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜浏览器、HTML 文件与网页的关系**

浏览器不是直接执行 HTML 里的中文说明，而是解析标签，建立 DOM 树，然后把内容绘制到屏幕。双击 index.html 使用 file:// 打开；日后接入接口时通常改用本地开发服务器（http://localhost）。

**知识点 2｜doctype、head、body、title、charset**

<!DOCTYPE html> 声明按现代 HTML 标准解析；html 包含整份文档；head 保存元数据，body 保存页面内容。meta charset="UTF-8" 避免乱码；viewport 让手机按设备宽度布局。

**知识点 3｜标题 h1/h2、段落 p、基本标签嵌套**

h1 是页面最高层级标题，h2 用于大板块，p 用于一段完整的话。标题不是用来随便放大字体的：应保持合理层级并成对闭合标签。

**跟写示例：index.html**

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>算法社团｜首页</title>
</head>
<body>
  <h1>算法社团</h1>
  <p>我们一起学习算法、参加比赛。</p>
  <h2>关于我们</h2>
  <p>每周组织一次训练。</p>
  <h2>近期活动</h2>
  <p>本周六：基础图论交流。</p>
</body>
</html>
```

**分步实践**

1. 创建 web-study 文件夹，并用 VS Code 打开。
2. 新建 index.html，输入示例并保存为 UTF-8。
3. 双击打开网页，修改 h1 后刷新，观察变化。
4. 把 title 改为“我的社团网站”，看浏览器标签页变化；最后新增“联系我们”板块。

**自测问题**：为什么修改 <title> 不会把网页正文里的大标题一起修改？
**参考解释**：title 是 head 中的文档元信息，通常用于浏览器标签页；正文标题属于 body 中的 h1，两者是不同的元素。
**排错提示**：看见源代码而不是页面？检查扩展名是否真为 .html、是否在浏览器里打开。


### Day 02｜链接、图片与语义化页面
**知识要点**
- [ ] a href 的地址、锚点与相对路径
- [ ] img src/alt 的含义
- [ ] header/nav/main/section/footer 的使用
**动手任务**：添加顶部导航、活动图和联系我们；使用 #events 跳转活动板块。
**验收**：导航可跳转；移走一张图片后能定位路径错误；图片有合适 alt。
- [ ] Day 02 当日完成并记录练习结果
**容易踩坑**：图片地址大小写和相对路径经常出错。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜a href 的地址、锚点与相对路径**

a 是可以导航的链接。href="https://..." 指向网址；href="about.html" 指向同目录文件；href="#events" 跳到当前页面 id="events" 的位置。路径是相对于当前 HTML 文件计算的。

**知识点 2｜img src/alt 的含义**

img 用 src 告诉浏览器去哪找文件，用 alt 描述图片信息。图片加载失败时 alt 有帮助，使用读屏器的人也会读到它；纯装饰图可用 alt=""，但有意义的图片不要留空。

**知识点 3｜header/nav/main/section/footer 的使用**

header 表示页眉，nav 是主要导航，main 是主要内容，section 是主题板块，footer 是页脚。这些标签有语义，不是浏览器自动帮你做好外观。

**跟写示例：index.html（插入到 body）**

```html
<header>
  <h1>算法社团</h1>
  <nav aria-label="页面导航">
    <a href="#about">关于我们</a>
    <a href="#events">近期活动</a>
  </nav>
</header>
<main>
  <section id="about"><h2>关于我们</h2><p>欢迎参加训练。</p></section>
  <section id="events">
    <h2>近期活动</h2>
    <img src="images/training.jpg" alt="社团成员在机房讨论算法题" width="420">
  </section>
</main>
<footer><p>2026 算法社团</p></footer>
```

**分步实践**

1. 在 web-study 内创建 images 文件夹，放一张你有使用权的照片并命名 training.jpg。
2. 将 h1 和导航放入 header，把主要板块放到 main。
3. 给两个 section 各设置唯一 id，测试导航的锚点跳转。
4. 故意把 src 改错，再打开开发者工具 Console/Network 查看失败的图片请求。

**自测问题**：index.html 位于网站根目录，照片位于 images/a.png，src 应怎样写？
**参考解释**：写成 src="images/a.png"（或 ./images/a.png）。图片路径相对于 index.html 所在目录。
**排错提示**：不要把本地绝对路径 C:\Users\... 写入网页：别人电脑上没有这条路径。


### Day 03｜CSS 选择器与文本排版
**知识要点**
- [ ] link 引入 style.css
- [ ] 标签、类、伪类选择器
- [ ] 颜色、字体、行高、背景、继承
**动手任务**：把样式放到 style.css，统一标题颜色、背景色、段落行高。
**验收**：可以用类名只修改一个板块的样式；解释 CSS 与 HTML 分工。
- [ ] Day 03 当日完成并记录练习结果
**容易踩坑**：别把所有样式都写成 style="..."。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜link 引入 style.css**

HTML 决定“是什么”，CSS 决定“长什么样”。用 <link rel="stylesheet" href="style.css"> 在 head 中连接样式文件；同目录才能直接这样写。

**知识点 2｜标签、类、伪类选择器**

h1 匹配所有一级标题；.card 匹配 class="card" 的元素；.card:hover 只匹配悬停状态。优先使用 class 写组件外观，少用过长的选择器链。

**知识点 3｜颜色、字体、行高、背景、继承**

color 修改文字色，background-color 修改背景；font-size 是字号、line-height 是行高。子元素可能继承字体属性，但一般不会继承 padding 或 border。

**跟写示例：style.css**

```css
/* index.html 的 head 加：<link rel="stylesheet" href="style.css"> */
body { font-family: Arial, sans-serif; background: #f6f8f8; color: #263238; }
h1 { color: #136b59; }
section { background: white; padding: 16px; margin: 16px 0; }
section p { line-height: 1.8; }
.highlight { color: #b34333; font-weight: bold; }
```

**分步实践**

1. 创建 style.css，在 index.html 的 head 引入。
2. 复制样式，刷新页面确认 h1 变色。
3. 在一个段落中加入 class="highlight"，只修改这个段落的文字颜色。
4. 故意写错 href 文件名，利用 DevTools Network 找到 style.css 404 或文件读取失败原因。

**自测问题**：只希望“近期活动”板块有蓝色标题，应该修改所有 h2 还是给该标题加类？
**参考解释**：优先给这个标题一个单独的 class，再写 .类名 选择器；修改所有 h2 会影响其他板块。
**排错提示**：选择器写 .card 时，HTML 应是 class="card"，不是 id="card"。


### Day 04｜盒模型：间距为什么不听话
**知识要点**
- [ ] margin / padding / border / content
- [ ] width 与 box-sizing:border-box
- [ ] 块级元素和行内元素的差别
**动手任务**：制作第一张活动卡片，包含标题、日期、说明、按钮。
**验收**：能用 DevTools 看出卡片最终宽度和四种间距。
- [ ] Day 04 当日完成并记录练习结果
**容易踩坑**：不要用几十个空格或多个 br 当布局。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜margin / padding / border / content**

浏览器里的每个元素都占据一个矩形盒子：内容 content → 内边距 padding → 边框 border → 外边距 margin。padding 在盒子内；margin 在盒子外，不属于背景区域。

**知识点 2｜width 与 box-sizing:border-box**

默认 content-box 的 width 只算内容宽度，padding/border 会额外增加总宽；box-sizing:border-box 会把 padding/border 纳入已设置的 width，更易控制布局。

**知识点 3｜块级元素和行内元素的差别**

div、section 默认通常独占一行；span、a 是常见行内元素，通常随文字排列。display 属性可以改变表现，但语义由标签本身决定。

**跟写示例：style.css**

```css
* { box-sizing: border-box; }
.card {
  width: 300px;
  padding: 20px;
  border: 1px solid #d9e1e0;
  margin: 16px 0;
  background: white;
  border-radius: 12px;
}
.card h3 { margin-top: 0; }
```

**分步实践**

1. 在 HTML 新增 <article class="card">，包含标题、时间和说明。
2. 按代码设置宽 300px、padding 20px、border 1px。
3. 在浏览器 DevTools 的 Computed → Box Model 查看各层数值。
4. 暂时删掉 box-sizing，比较卡片总宽是 300px 还是 342px，再恢复。

**自测问题**：width:300px；左右 padding 各 20px；左右 border 各 1px，默认 content-box 的总宽是多少？
**参考解释**：342px：300 + 20×2 + 1×2。设置 border-box 后，总宽变为 300px。
**排错提示**：margin 的垂直折叠会造成距离“不按加法计算”；先检查实际盒模型，不要盲目调大数字。


### Day 05｜Flexbox：导航和横向排列
**知识要点**
- [ ] display:flex 与主轴/交叉轴
- [ ] justify-content、align-items、gap
- [ ] flex-wrap、flex-grow 基本含义
**动手任务**：让 logo 与导航分列，导航链接排列整齐，窄屏可换行。
**验收**：无需大量 position:absolute 即可完成导航布局。
- [ ] Day 05 当日完成并记录练习结果
**容易踩坑**：justify-content 控制主轴，不一定是水平方向。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜display:flex 与主轴/交叉轴**

Flexbox 负责单维排列：一排或一列。给父元素 display:flex，子元素自动参与 Flex 布局；默认主轴水平向右（direction:row），修改方向后主轴也会改变。

**知识点 2｜justify-content、align-items、gap**

justify-content 控制主轴方向的排列，align-items 控制交叉轴方向的对齐。flex-direction:column 时，justify-content 不再是“水平对齐”。

**知识点 3｜flex-wrap、flex-grow 基本含义**

gap 是项目之间的间隔；flex-wrap:wrap 允许空间不足时换行；flex:1 常用来让某个区域占据剩余空间，不等于写死宽度。

**跟写示例：style.css**

```css
* { box-sizing: border-box; }
.topbar { display: flex; align-items: center; gap: 20px; }
.topbar nav { margin-left: auto; display: flex; gap: 14px; flex-wrap: wrap; }
.topbar a { color: #136b59; text-decoration: none; }
@media (max-width: 600px) {
  .topbar { align-items: flex-start; flex-direction: column; }
  .topbar nav { margin-left: 0; }
}
```

**分步实践**

1. 给 header 加 class="topbar"，其中放社团名称与 nav。
2. 写 display:flex 和 gap，观察导航如何排列。
3. 把 flex-direction 改成 column，验证两个对齐属性的作用。
4. 缩窄窗口，看链接何时拥挤；再试 flex-wrap 和示例里的媒体查询。

**自测问题**：当 flex-direction:column 时，justify-content 控制水平还是垂直方向？
**参考解释**：主轴改为纵向，所以 justify-content 控制纵向分布；align-items 控制横向对齐。
**排错提示**：给单个元素 text-align:center 不能取代父元素 Flexbox 对多个子元素的布局。


### Day 06｜CSS 组合练习：活动区
**知识要点**
- [ ] 类名复用与组合
- [ ] 卡片图片 object-fit 和圆角
- [ ] 按钮/链接 hover 与 focus 状态
**动手任务**：做 3 张风格一致的活动卡片，并加入可见的焦点样式。
**验收**：三个卡片的内边距一致；Tab 键能看到当前焦点。
- [ ] Day 06 当日完成并记录练习结果
**容易踩坑**：别给纯装饰 div 加上假的按钮行为。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜类名复用与组合**

同类卡片共享 .card 样式，内容可以不同。CSS 的复用原则是“同样的结构同样的类”，不要为三张卡片各复制一次相同声明。

**知识点 2｜卡片图片 object-fit 和圆角**

object-fit:cover 可以让图片填充固定比例的区域并裁剪边缘；它不会改变图片原文件的内容。对内容重要的图片，裁剪前注意不要截掉关键信息。

**知识点 3｜按钮/链接 hover 与 focus 状态**

鼠标可看到 :hover，但键盘用户通常依赖 :focus-visible。链接用 a，提交或动作使用 button；具有功能的元素不应该伪装成普通 div。

**跟写示例：style.css**

```css
.cards { display: flex; gap: 16px; flex-wrap: wrap; }
.card { flex: 1 1 230px; border: 1px solid #ddd; border-radius: 12px; overflow: hidden; }
.card img { width: 100%; aspect-ratio: 16/9; object-fit: cover; }
.card-content { padding: 16px; }
.card a { color: #136b59; }
.card a:hover { text-decoration: underline; }
.card a:focus-visible { outline: 3px solid #ffb347; outline-offset: 4px; }
```

**分步实践**

1. 用同一个 .card 结构写三张不同内容的活动卡片。
2. 给卡片容器加 .cards 类，使用 Flexbox 排列。
3. 给每张图片设置 16:9 的展示比例，观察是否拉伸。
4. 不断按 Tab，在三个活动链接之间移动，确认焦点清晰可见。

**自测问题**：应该把打开“活动详情页”的元素写成 a 还是 button？
**参考解释**：导航到另一个页面或 URL 应用 <a href="...">；触发当前页动作才主要用 <button>。
**排错提示**：不要只写 :hover 忘了键盘焦点；也不要把可点击卡片实现为没有键盘支持的 div。


### Day 07｜第 1 周阶段验收
**知识要点**
- [ ] HTML 标题层级和语义检查
- [ ] 盒模型与 Flexbox 复盘
- [ ] 文件路径、浏览器开发工具
**动手任务**：关闭参考资料，独立重建社团首页的页眉、介绍、活动卡片、页脚。
**验收**：从空文件做出完整初版；在 README 写明如何打开与当前缺点。
- [ ] Day 07 当日完成并记录练习结果
**容易踩坑**：复现失败的部分才是下一周要补的知识。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜HTML 标题层级和语义检查**

检查标题结构：页面核心标题一般有一个 h1，各主要板块用 h2，板块内活动标题用 h3。语义顺序有助于阅读理解与辅助技术。

**知识点 2｜盒模型与 Flexbox 复盘**

盒模型解决“卡片内部与外部留白”，Flexbox 解决“一排多个元素如何排列”；它们解决的问题不同，需要组合使用。

**知识点 3｜文件路径、浏览器开发工具**

网页打开不等于没有问题。浏览器 F12 的 Elements 检查结构，Console 查 JS/资源错误，Network 看实际加载请求；记录现象和修复。

**跟写示例：README.md**

```md
# 算法社团静态首页

## 打开方法
用浏览器打开 `index.html`。

## 已完成
- 顶部导航和页面锚点
- 三张活动卡片
- HTML/CSS 文件分离

## 已知限制
- 尚未连接后端，不能真正提交报名数据
- 手机端布局下周继续优化
```

**分步实践**

1. 暂时关闭参考文件，从空白 HTML 文档重建页眉、主内容和页脚。
2. 只在卡住的时候查前六天的概念讲义，标记卡住了哪一个知识点。
3. 完成后用 F12 检查图片、锚点和样式；至少修改一次自己发现的问题。
4. 写一份 README，明确运行方法、已完成和待做功能。

**自测问题**：为什么“能看到三张卡片”还不能证明你学会了 HTML/CSS？
**参考解释**：还要能解释代码里的结构、布局原因，并在不复制模板的情况下完成类似页面、定位路径或样式错误。
**排错提示**：本日侧重独立复现；允许查文档，但不要让 AI 一次性生成完整作业。


### Day 08｜Grid：多列布局不靠手算
**知识要点**
- [ ] display:grid 与 grid-template-columns
- [ ] repeat/minmax/gap
- [ ] Grid 与 Flex 的使用边界
**动手任务**：把活动区改成桌面 3 列、窄屏能自动换行的卡片网格。
**验收**：增加第四张卡片时不必手工重新计算每个宽度。
- [ ] Day 08 当日完成并记录练习结果
**容易踩坑**：能用 Grid 就别用绝对定位写三列。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜display:grid 与 grid-template-columns**

Grid 是二维布局：同时安排列和行。display:grid 给父容器建立网格，grid-template-columns 定义列宽，gap 定义格子间距。

**知识点 2｜repeat/minmax/gap**

repeat(3,1fr) 代表三列均分；minmax(最小,最大) 控制列宽区间，auto-fit 能在容器变窄时减少列数。

**知识点 3｜Grid 与 Flex 的使用边界**

导航通常按一维排布适合 Flexbox；活动卡片横纵都有规则，Grid 更直观。两者不是“谁更高级”，而是适用场景不同。

**跟写示例：style.css**

```css
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 240px), 1fr));
  gap: 20px;
}
.card { min-width: 0; padding: 20px; background: white; border: 1px solid #ddd; }
.card h3 { overflow-wrap: anywhere; }
```

**分步实践**

1. 将 Day 6 的活动容器从 flex 改为 grid。
2. 添加第四、第五张活动卡片，不修改列数。
3. 把浏览器从 1440px 拖到 375px，观察每行卡片个数变化。
4. 尝试改成 repeat(3,1fr)，观察窄屏如何挤压，再改回自适应。

**自测问题**：Grid 的 1fr 是固定 1 像素吗？
**参考解释**：不是。fr 表示网格容器里可分配空间的份额，多个 1fr 列通常等比例分配剩余空间。
**排错提示**：固定三列的 Grid 在手机上可能会拥挤；根据内容宽度调整列数。


### Day 09｜响应式与媒体查询
**知识要点**
- [ ] viewport、相对尺寸、max-width
- [ ] @media 的基础语法
- [ ] 内容驱动的断点设计
**动手任务**：实现桌面多列、手机单列的首页布局。
**验收**：在 360px、768px 和 1440px 都没有页面横向溢出。
- [ ] Day 09 当日完成并记录练习结果
**容易踩坑**：响应式不只是把文字缩小。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜viewport、相对尺寸、max-width**

响应式目标是让内容在不同宽度都可读。viewport 元信息让移动浏览器正确按设备宽度计算布局；max-width 防止大屏内容无限拉宽。

**知识点 2｜@media 的基础语法**

@media (max-width: 640px) 表示视口宽度不超过 640px 时生效；断点依据内容什么时候出现拥挤选取，而不是死记手机型号。

**知识点 3｜内容驱动的断点设计**

常用相对单位有 %、rem、vw。宽度建议用 width:100% 配合 max-width；小屏要考虑外边距、图片宽度与长单词。

**跟写示例：style.css**

```css
body { margin: 0; }
.container { width: min(100% - 32px, 1080px); margin-inline: auto; }
.intro { display: grid; grid-template-columns: 2fr 1fr; gap: 28px; }
img { max-width: 100%; height: auto; }
@media (max-width: 680px) {
  .intro { grid-template-columns: 1fr; }
}
```

**分步实践**

1. 把页面内容放进 class="container" 的容器。
2. 大屏为简介区域设置 2:1 两列；窄屏改为单列。
3. 使用 DevTools 设备模拟分别检查 360px、768px、1440px。
4. 找到第一次出现重叠或横向滚动的宽度，说明你选断点的理由。

**自测问题**：响应式是不是给每种手机型号写一个 @media？
**参考解释**：不是。按页面内容的承载能力选择少量必要断点，配合弹性宽度和自适应布局，避免为机型逐一硬编码。
**排错提示**：不要为隐藏错误而给 body 随手加 overflow-x:hidden；先定位超宽元素。


### Day 10｜文字、颜色和视觉层次
**知识要点**
- [ ] 字体大小、行高、可读行长
- [ ] 颜色对比与间距系统
- [ ] 卡片信息层级与留白
**动手任务**：建立 4–5 个颜色/间距变量，统一整个网站视觉风格。
**验收**：不依赖随机配色；正文清晰易读，重要按钮醒目。
- [ ] Day 10 当日完成并记录练习结果
**容易踩坑**：漂亮不等于信息拥挤，也不等于加满阴影。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜字体大小、行高、可读行长**

好的排版先考虑信息层级：一级标题、板块标题、正文、辅助信息的大小和对比应有差别；不要让所有文字一样显眼。

**知识点 2｜颜色对比与间距系统**

颜色最好有语义：正文色、次要文字色、背景色、强调色。正文与背景要有足够对比度，可参考 WCAG 标准的文字对比度要求。

**知识点 3｜卡片信息层级与留白**

CSS 自定义属性 --brand 与 var(--brand) 便于集中维护主题。间距也可以使用 8/12/16/24/32 的简单尺度，避免任意数字到处散落。

**跟写示例：style.css**

```css
:root { --brand: #156a5a; --text: #243333; --muted: #526866;
  --surface: #fff; --page: #f4f7f6; --space: 16px; }
body { background: var(--page); color: var(--text); line-height: 1.7; }
.container { max-width: 1040px; margin: auto; padding: 0 var(--space); }
h1 { font-size: clamp(28px, 5vw, 44px); line-height: 1.2; }
p { max-width: 70ch; }
.muted { color: var(--muted); }
```

**分步实践**

1. 确定主色、文字色、辅助色、页面背景和卡片背景。
2. 把原来散落的十几个颜色改为 CSS 变量。
3. 用手机和电脑分别查看正文：不应太小、不应横向跨过整屏。
4. 让同学快速扫视 5 秒，说出最重要的信息是什么。

**自测问题**：为什么把 12px 的正文改成 8px 不能算“更紧凑的专业设计”？
**参考解释**：会显著降低可读性和可访问性。合理的信息组织、间距和行长比一味缩小文字更有效。
**排错提示**：颜色对比不足和超长行宽比是否“高大上”更直接影响阅读体验。


### Day 11｜手机导航与小屏问题排查
**知识要点**
- [ ] flex-wrap 与媒体查询的组合
- [ ] overflow 与图片超宽的定位
- [ ] DevTools 设备模拟
**动手任务**：修复小屏导航换行、过长标题、宽图片等问题。
**验收**：320–390px 模拟宽度能正常浏览，实际手机至少测试一次。
- [ ] Day 11 当日完成并记录练习结果
**容易踩坑**：别用 overflow-x:hidden 掩盖所有布局错误。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜flex-wrap 与媒体查询的组合**

手机端的问题常来自固定宽度、图片尺寸、过长文本或 flex 子项不肯缩小。排查时先选中超宽元素，检查实际计算宽度。

**知识点 2｜overflow 与图片超宽的定位**

min-width:0 能让 Flex/Grid 子项在某些场景允许缩小；overflow-wrap:anywhere 让异常长串字符可断行。它们是针对问题的工具。

**知识点 3｜DevTools 设备模拟**

模拟器方便快速检查宽度，但不能完全替代真机：触摸目标、系统字体、移动浏览器行为可能不同。

**跟写示例：style.css**

```css
img, video { max-width: 100%; height: auto; }
.flex-main { display: flex; gap: 20px; }
.flex-main > * { min-width: 0; }
.long-title { overflow-wrap: anywhere; }
@media (max-width: 600px) {
  .flex-main { flex-direction: column; }
  nav { flex-wrap: wrap; }
}
```

**分步实践**

1. 在一张活动卡片内放一段 80 字长标题以及一长串无空格文本。
2. 检查 320px、375px、390px 宽度，发现水平滚动时用 Elements 定位元素。
3. 有针对性地使用 min-width、max-width 或 overflow-wrap 修复。
4. 用真实手机打开页面（本地文件传过去或部署预览），检查按钮是否方便点按。

**自测问题**：页面横向溢出，直接设置 body{overflow-x:hidden} 是最佳解决方式吗？
**参考解释**：不是。它可能把被挤出的内容切掉。应先找出超宽元素再修复其宽度或换行策略。
**排错提示**：修复后必须再次测试桌面布局，避免窄屏改动把大屏破坏。


### Day 12｜表单外观与无障碍
**知识要点**
- [ ] form、label、input、button 结构
- [ ] required、placeholder 与 label 区别
- [ ] 键盘焦点、disabled 状态与 alt
**动手任务**：添加联系表单界面（暂不发送数据），包含姓名、意见和提交按钮。
**验收**：Tab 可以依次聚焦字段；label 点击后能聚焦输入框。
- [ ] Day 12 当日完成并记录练习结果
**容易踩坑**：这个阶段表单只是界面，不能假装信息已发送到后台。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜form、label、input、button 结构**

form 表示一个表单；label 让字段有可识别的名称。label 的 for 值要与 input 的 id 一致。button 默认在 form 内常会触发表单提交。

**知识点 2｜required、placeholder 与 label 区别**

placeholder 是输入提示，不等于 label：用户输入后 placeholder 往往消失。required 可以让浏览器进行基础必填检查，但不能替代服务端校验。

**知识点 3｜键盘焦点、disabled 状态与 alt**

必须能用键盘操作表单：Tab 切换焦点，focus-visible 保留清晰提示。若表单没有后端，不能在点击后显示“已经收到你的报名”。

**跟写示例：index.html（表单片段）**

```html
<form action="#" method="get">
  <label for="student-name">姓名</label>
  <input id="student-name" name="name" type="text" required>
  <label for="message">想交流的内容</label>
  <textarea id="message" name="message" rows="3" required></textarea>
  <button type="submit">检查表单字段</button>
</form>
<!-- 教学演示：当前没有服务器，不会真的发送给社团。 -->
```

**分步实践**

1. 在“联系我们”区域放入 form、label、input、textarea、button。
2. 核对每个 label 的 for 和字段的 id。
3. 留空点击提交，观察浏览器默认的必填提示。
4. 暂不连接任何接收数据的服务；在页面明确注明“演示表单，暂不接受报名”。

**自测问题**：字段已经写了 placeholder="请输入姓名"，是否可以删除 label？
**参考解释**：不建议。placeholder 会在输入后消失，且无法稳定替代表单控件的可访问名称。保留明确的 label。
**排错提示**：浏览器自带 required 只提供便捷反馈；真正的身份和业务验证将由后端完成。


### Day 13｜整理、复用、调试
**知识要点**
- [ ] CSS 重复规则清理
- [ ] 命名规范与目录组织
- [ ] Elements/Console/Network 的入门
**动手任务**：整理 css/、images/ 目录，修复失效资源和不一致样式。
**验收**：无明显控制台错误；项目目录清晰；同学能看懂代码。
- [ ] Day 13 当日完成并记录练习结果
**容易踩坑**：不要为纯静态页面过度拆成几十个文件。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜CSS 重复规则清理**

重复 CSS 规则会增加维护成本。删规则前先查它影响哪些元素，不要仅为了“代码短”把有语义的类全部合并。

**知识点 2｜命名规范与目录组织**

文件名、资源路径和目录结构是协作基础。推荐 index.html、style.css、images/；README 写如何运行及哪些功能不具备。

**知识点 3｜Elements/Console/Network 的入门**

Elements 可看实时 DOM/CSS；Console 可看 JavaScript 错误；Network 可看每个资源请求和响应。用证据定位，不是改一行就祈祷。

**跟写示例：建议目录**

```text
web-study/
├── index.html
├── style.css
├── images/
│   ├── training.jpg
│   └── banner.jpg
└── README.md
```

**分步实践**

1. 检查当前目录，删除无用的重复图片和临时复制文件。
2. 用 DevTools 的 Network 刷新，确认 HTML/CSS/图片都成功加载。
3. 故意把一个样式类写错，利用 Elements 查出为什么没有样式。
4. 让同学从零按 README 打开网页；记录他遇到的问题并修正文档。

**自测问题**：页面某张图片不显示，应优先改 CSS，还是先看 Network 请求与 src 路径？
**参考解释**：先检查 src 的实际路径以及 Network 是否加载成功。资源未加载时，修改尺寸或 object-fit 没用。
**排错提示**：可以让 AI 做代码审查，但必须要求给出可以复现的问题位置与真实证据。


### Day 14｜第二周毕业小项目
**知识要点**
- [ ] 结构、布局、响应式综合应用
- [ ] 多视口手测与基本验收
- [ ] 简单 README 与截图留存
**动手任务**：不复制前 13 天代码，从空目录制作一页「社团活动日历 / 社团招新页」。
**验收**：独立完成：清晰结构 + 至少 3 个区块 + 手机适配 + 4 张截图 + README。
- [ ] Day 14 当日完成并记录练习结果
**容易踩坑**：允许查文档；但核心页面不要一键交给 AI 代写。

#### 对应知识讲义（不仅是打卡清单）

**知识点 1｜结构、布局、响应式综合应用**

独立项目要同时检验语义、布局、可访问性和阅读体验。可查文档，但不能复制原页面所有代码再换名字充作新作品。

**知识点 2｜多视口手测与基本验收**

测试不是“我自己看着还行”：应列出真实检查宽度、链接、键盘、图片、长文本等项目，并保留截图或问题记录。

**知识点 3｜简单 README 与截图留存**

README 相当于交接文档，至少写用途、打开方法、功能、已知限制。修改需求时记录做过什么和为何这样做。

**跟写示例：README.md（结业提交样例）**

```md
# 社团招新页

## 运行
用浏览器打开 `index.html`。

## 功能
- 社团介绍、活动日程、联系方式
- 大小屏响应式布局

## 已知限制
- 暂无真实后端，表单仅作展示

## 验收证据
- `screenshots/360.png`
- `screenshots/768.png`
- `screenshots/1440.png`
```

**分步实践**

1. 新建 web-final 文件夹，不复制旧项目全部 HTML/CSS。
2. 设计一张“社团招新页”或“社团活动日历”：至少 3 个语义化区块、3 张活动卡片。
3. 独立实现电脑与手机布局，图片都有正确 alt，导航和焦点可用。
4. 在 360/768/1440px 与真实手机测试，截图并记录至少一项修复。
5. 提交 README 和完整源码，让别人能打开并检查。

**自测问题**：页面样式很好看，但导航跳转无效、手机横向溢出，可以算阶段通过吗？
**参考解释**：不能。项目必须达到功能与布局验收标准；美观不是替代功能的理由。
**排错提示**：今天不给完整页面答案，因为重点是检验你能否自己综合使用前 13 天的知识。


## 完整知识点教材：共同基础（第 1–8 周）

### 01｜第 1–2 周 · HTML + CSS 入门
**目标**：会从空文件创建 HTML，添加文字/图片/导航，使用 CSS 完成单页布局。
**知识点 / 掌握标准**
- [ ] **浏览器与文件**：区分本地 .html 文件、URL、网页资源；能在 DevTools 的 Elements 中看到渲染后的 DOM。
    - **知识讲解**：浏览器把 HTML 解析为 DOM、把 CSS 计算为样式后呈现；file:// 是本机文件，https:// 是网络地址，两者权限与资源加载行为不完全相同。
    - **跟练任务**：把页面用浏览器打开，再按 F12 → Elements，选中页面标题，定位对应的 h1。
- [ ] **HTML 文档骨架**：解释 doctype、html、head、body、title、charset、viewport 的作用。
    - **知识讲解**：head 里写页面元数据，不放正文；body 里的元素才形成页面内容。viewport 决定手机视口如何缩放。
    - **跟练任务**：暂时删除 viewport，在设备模拟器比较效果；恢复它后写明 title 与 h1 的区别。
- [ ] **常见语义标签**：正确选用 header、nav、main、section、article、footer 和 h1–h6，不只用 div 堆页面。
    - **知识讲解**：main 是主要内容，article 适合能单独理解的活动公告；div 只提供通用容器，自己不说明内容意义。
    - **跟练任务**：把原来只有 div 的页面换为 header/nav/main/section/article/footer，检查 h1→h2→h3 层级。
- [ ] **文字、列表与链接**：使用 p、strong、ul/ol/li、a；知道相对路径、绝对路径和 # 锚点。
    - **知识讲解**：a 的 href 决定跳转目标：#id 是页内跳转、相对路径基于当前文档、完整 URL 指向外部资源。
    - **跟练任务**：创建 ul/li 活动清单和“跳到活动”链接，点击后确认 URL 哈希与定位都改变。
- [ ] **图片与可访问性**：会用 img、alt；知道有意义的图片描述与纯装饰图的区别。
    - **知识讲解**：alt 是图片的文本替代。信息图应描述实际信息；装饰图可用 alt=""，不能随手写“图片”两字。
    - **跟练任务**：用一张活动照片写有意义的 alt，临时把 src 写错，观察替代文本出现。
- [ ] **表单入门**：用 label、input、button 组成搜索框；理解 name、type、required。
    - **知识讲解**：label 为字段提供名称，name 常用作提交字段键，type 控制键盘与浏览器行为，required 是客户端便捷检查。
    - **跟练任务**：写一个姓名和邮箱输入框，各关联 label，空提交时查看浏览器提醒。
- [ ] **CSS 引入方式**：能正确用 link 标签加载独立的 style.css，并在 DevTools 检查样式来源。
    - **知识讲解**：CSS 与 HTML 分开可以让多个页面共用视觉规则；相对路径错误时，HTML 仍显示但样式不生效。
    - **跟练任务**：将内联样式移至 style.css，使用 link 引入，故意改错 href 再用 Network 定位。
- [ ] **选择器与层叠**：理解标签/类/伪类、继承、优先级；避免滥用 !important。
    - **知识讲解**：同级的 .class、标签和伪类等选择器会受到优先级和源码顺序影响；部分属性会被子元素继承。
    - **跟练任务**：给 h2 写两条冲突的颜色规则，预测哪条生效，再用 Computed 栏确认。
- [ ] **盒模型**：能区分 content、padding、border、margin，理解 box-sizing:border-box。
    - **知识讲解**：content 是内容尺寸；padding 是内部空白；border 是边；margin 是外部间距。border-box 有利于控制总宽。
    - **跟练任务**：设 width:300px 与左右 padding:20px，分别在两种 box-sizing 下量出实际宽度。
- [ ] **Flexbox 基础**：通过 display:flex、gap、justify-content、align-items 做导航栏。
    - **知识讲解**：Flex 是一维布局：父元素建立主轴，justify-content 排主轴、align-items 排交叉轴。
    - **跟练任务**：把网站导航改为 flex；调整 flex-direction 后说明 justify-content 改变了哪个方向。
- [ ] **文本与视觉层级**：能控制字体、行高、颜色、对比度和内容最大宽度。
    - **知识讲解**：正文不是越小越精致；标题、正文、注释要有清晰层级和足够对比，段落行长不宜无限扩展。
    - **跟练任务**：给 h1、h2、p 分别设置字体与行高，再请同学指出最重要的消息。
- [ ] **简单响应式**：使用 max-width、百分比和 flex-wrap，让手机端不出现水平滚动条。
    - **知识讲解**：max-width 防止大屏文字过宽；width:100%、flex-wrap 能允许元素在窄屏收缩或换行。
    - **跟练任务**：把宽度从 1200px 改到 375px，确认导航不卡死、图片不撑出页面。
#### 本阶段配套综合实战

**把 HTML 与 CSS 真正连接起来**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```html
<!-- index.html → head -->
<link rel="stylesheet" href="style.css">
<!-- index.html → body -->
<main class="container">
  <h1>社团活动</h1>
  <article class="card"><h2>图论训练</h2><p>周六 19:00</p></article>
</main>
<!-- style.css -->
<!-- .container {max-width: 900px; margin: auto; padding: 16px;} -->
<!-- .card {padding: 20px; border: 1px solid #ddd;} -->
```

**练习步骤**

1. 先自己写 HTML，让关闭 CSS 时内容仍有逻辑。
2. 再引入 style.css，不要把全部样式写在标签内部。
3. 对卡片做盒模型检查，再实现一个能换行的导航。

**思考题**：如果图片不出现而文字正常，第一步检查 HTML 路径还是加大 z-index？
**参考答案**：先检查 img 的 src 与 Network 状态，不应先猜测 CSS 层级。

**实战作品**：社团介绍页：导航、社团简介、三张活动卡片、联系方式与页脚；不使用框架。
**验收清单**
- [ ] 电脑宽屏与约 375px 手机宽度均不溢出
- [ ] 导航链接与图片均可用；无失效路径
- [ ] 关闭 CSS 后仍能按逻辑顺序阅读正文
**常见错误**：一开始照搬炫酷动画；把所有内容写在 div 里；用空格和绝对定位硬凑布局。
**推荐资料**：[MDN：Web 入门（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Getting_started)、[MDN：Web 核心学习（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core)、[The Odin Project：Foundations](https://www.theodinproject.com/paths/foundations/courses/foundations)

### 02｜第 3–4 周 · 页面布局与响应式
**目标**：面对一张中等复杂度页面图，能选择合适布局手段并独立实现。
**知识点 / 掌握标准**
- [ ] **Flexbox 进阶**：弄清主轴/交叉轴、flex-grow、flex-shrink、flex-basis，避免无意义的宽度计算。
    - **知识讲解**：flex-grow 参与分配剩余空间，flex-shrink 在空间不足时允许收缩，flex-basis 是初始主轴尺寸。固定宽度太多会相互冲突。
    - **跟练任务**：做“搜索框 + 提交按钮”一排布局：搜索框 flex:1，按钮保持本身宽度。
- [ ] **Grid 双维布局**：会写 grid-template-columns、repeat、minmax、auto-fit，做多列卡片。
    - **知识讲解**：Grid 同时控制行和列；repeat(auto-fit,minmax(...)) 可根据容器空间重新排卡片，fr 是空间比例而非固定长度。
    - **跟练任务**：给三张活动卡片写自适应网格，再新增第四张验证是否无需手调宽度。
- [ ] **定位与层级**：解释 relative/absolute/fixed/sticky 与 z-index，不用定位替代正常文档流。
    - **知识讲解**：relative 仍在普通文档流中；absolute 通常相对定位祖先定位；fixed 相对视口；sticky 随滚动粘附。
    - **跟练任务**：做一个卡片右上角小角标：卡片设 relative，角标设 absolute，记录为何不影响正文。
- [ ] **媒体查询**：为常见窄屏场景设置 @media；围绕内容断点设计而非只记设备型号。
    - **知识讲解**：媒体查询针对条件切换规则，但移动优先可以先写单列默认样式，再为宽屏增强为多列。
    - **跟练任务**：从 360px 开始排版，之后添加 min-width:768px 的双列规则并截图。
- [ ] **图片呈现**：会用 aspect-ratio、object-fit、max-width，防止图片拉伸。
    - **知识讲解**：object-fit:cover 裁切填充，不是压缩文件；aspect-ratio 控制展示框比例，max-width 防止图片超容器。
    - **跟练任务**：用竖图和横图各放一张卡片，统一 16:9 预览框，检查有无不合理裁剪。
- [ ] **CSS 变量**：用 --color 等自定义属性组织配色和间距，减少复制粘贴。
    - **知识讲解**：CSS 自定义属性在声明处定义，例如 --brand:#156a5a，通过 var(--brand) 使用，统一改主题色只需改一个变量。
    - **跟练任务**：为背景、正文、强调色写三个变量并在三个区域复用，修改变量观察全站改变。
- [ ] **交互状态**：为 hover、focus-visible、disabled 提供合理反馈，键盘可见焦点。
    - **知识讲解**：hover 是指针交互，focus-visible 让键盘焦点可见；disabled 的状态要真正阻止无效操作。
    - **跟练任务**：不用鼠标只按 Tab 浏览导航与按钮，补足看不见的焦点框。
- [ ] **表单与语义**：让 label 正确关联 input；不要用 div 冒充 button。
    - **知识讲解**：label、button、nav 自带浏览器和辅助技术可理解的语义；纯 div 没有按钮默认键盘行为。
    - **跟练任务**：将“提交”伪按钮 div 换成 button，给两个 input 写清晰 label，按 Enter 测试。
- [ ] **无障碍基础**：用 Tab 键完成主要操作，检查颜色对比度、图片 alt、标题层级。
    - **知识讲解**：无障碍不是最后加一个 aria-label；从正确语义、合理标题顺序、alt、键盘操作开始更可靠。
    - **跟练任务**：做 5 分钟键盘巡检：能否访问所有导航、焦点是否可见、操作名称是否明确。
- [ ] **开发者工具调试**：使用 Elements、Computed、设备模拟器定位布局错位与溢出。
    - **知识讲解**：Elements 看 DOM 与应用样式，Computed 看最终值，设备模拟发现窄屏问题；要从证据确定哪个规则生效。
    - **跟练任务**：故意写一个 width:1200px 导致溢出，用 DevTools 找到该元素并修复。
- [ ] **网页可读性**：控制行长、字号、行高、段落间距；避免「好看但看不清」。
    - **知识讲解**：正文行宽太长难以回读，行高太小拥挤。max-width:65ch 和 line-height:1.6 是可调整的起点。
    - **跟练任务**：测量桌面版正文长度并限制行长，再比较 1.1 与 1.7 的行高可读性。
#### 本阶段配套综合实战

**用 Flex + Grid 完成响应式布局**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```css
.top { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.cards { display: grid; gap: 16px;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 240px), 1fr)); }
.card img { max-width: 100%; aspect-ratio: 16/9; object-fit: cover; }
@media (max-width: 640px) { .top { flex-direction: column; align-items: start; } }
```

**练习步骤**

1. 页眉用 Flex，卡片区用 Grid，先别写绝对定位。
2. 模拟 360/768/1440px，检查图片、长标题和导航。
3. 用键盘 Tab 遍历链接，修复焦点不可见问题。

**思考题**：为什么卡片区多列用 Grid，导航用 Flex 通常更省事？
**参考答案**：卡片涉及行列网格，导航主要是一维排列，布局工具与结构相匹配。

**实战作品**：完整社团首页：大屏三列活动卡片、手机单列、顶部导航、公告区与联系区。
**验收清单**
- [ ] 在 360 / 768 / 1440px 宽度分别截图检查
- [ ] Tab 可访问按钮与链接，焦点有可见样式
- [ ] 能口头说明为什么这一区域选择 Grid 而另一处用 Flex
**常见错误**：把响应式理解为缩小字体；只在自己的屏幕上调一次；滥用 px 固定宽度。
**推荐资料**：[MDN：Web 核心学习（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core)、[MDN：Web 无障碍（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core/Accessibility)、[The Odin Project：Foundations](https://www.theodinproject.com/paths/foundations/courses/foundations)

### 03｜第 5–6 周 · JavaScript 与 DOM
**目标**：不借助框架，写出活动搜索、筛选、展开与本地收藏等功能。
**知识点 / 掌握标准**
- [ ] **JS 与 C++ 区别**：掌握 let/const、null/undefined、真值、===；特别注意隐式类型转换。
    - **知识讲解**：JS 使用 let/const，比较推荐 ===；null 表示明确的空值，undefined 常表示未赋值。0、空字符串在 if 中是假值。
    - **跟练任务**：预测 0==false 与 0===false，再在控制台验证；解释为何输入值往往还是字符串。
- [ ] **对象与数组**：能用对象保存一条活动记录，使用 map/filter/find/sort 等处理数据。
    - **知识讲解**：对象承载一条活动 {id,title}，数组承载多条；filter 返回满足条件的新数组，map 转换每一项。
    - **跟练任务**：建立三条活动对象，filter 只保留“算法”类型，map 得到所有活动标题。
- [ ] **函数与作用域**：函数、箭头函数、闭包、局部变量；能读懂回调函数。
    - **知识讲解**：函数帮助复用逻辑；箭头函数常作为回调传给 filter 等方法。闭包能让回调记住外部作用域里的变量。
    - **跟练任务**：把搜索逻辑写为 filterEvents(events, keyword)，别把筛选和 DOM 渲染混在一起。
- [ ] **DOM 查询和更新**：使用 querySelector、textContent、createElement、append；理解 DOM 是网页对象树。
    - **知识讲解**：DOM 是当前网页可操作的对象树；textContent 写纯文本更直接，createElement + append 构造元素。
    - **跟练任务**：用 querySelector 选出 ul，再由 JS 创建三条 li 活动信息，而不是手工复制 HTML。
- [ ] **事件机制**：会用 addEventListener、event.target、preventDefault，理解事件冒泡。
    - **知识讲解**：addEventListener 注册事件处理函数；事件冒泡使子元素事件传播到父元素，preventDefault 可取消默认提交或跳转。
    - **跟练任务**：给活动列表做事件委托：点击某个“收藏”按钮时从 data-id 取得活动编号。
- [ ] **表单处理**：读取输入值并验证，处理空字符串、异常输入和重复提交。
    - **知识讲解**：浏览器读 input.value 通常得到字符串；输入不可信，先 trim、检查长度和格式再处理。
    - **跟练任务**：输入全空格时显示“请输入关键词”，不要出现空白成功提示。
- [ ] **JSON**：掌握对象和 JSON 字符串的区别；用 JSON.stringify/parse 序列化数据。
    - **知识讲解**：JavaScript 对象与 JSON 字符串不是同一回事：JSON 需要双引号包键且不包含函数；parse/stringify 在二者间转换。
    - **跟练任务**：将活动数组 JSON.stringify 后输出，再 JSON.parse 恢复，检查对象内容是否一致。
- [ ] **本地持久化**：使用 localStorage 保存筛选条件或收藏；明白它不是后台数据库。
    - **知识讲解**：localStorage 保存同源浏览器键值字符串，不是用户共享数据库；用户可以清除、更改这些值。
    - **跟练任务**：保存收藏活动 ID 数组，刷新后恢复；在 Application 面板删除键后观察页面状态。
- [ ] **异步的原因**：能解释同步/异步、Promise、async/await 和 try/catch。
    - **知识讲解**：Promise 代表未来结果，await 等待 Promise 解决；try/catch 处理拒绝，代码语句依然可能按异步时序执行。
    - **跟练任务**：写一个 async 函数 await Promise.resolve(42)，在执行前后打印日志，观察顺序。
- [ ] **fetch 与状态**：能请求 JSON 并处理 loading、空列表、网络错误、非 2xx 响应。
    - **知识讲解**：fetch 仅在网络层失败时自动 reject；服务器返回 404/500 时仍会得到 Response，需要检查 response.ok。
    - **跟练任务**：请求不存在的 JSON 地址，观察状态码；分别渲染加载中、失败、无结果。
- [ ] **错误定位**：会用 Console、断点、Network 查看实际请求与报错，而不盲目改代码。
    - **知识讲解**：Console 的错误堆栈给行号，Network 给请求 URL、状态和响应；断点能停下观察变量值。
    - **跟练任务**：故意把 events 写错为 event，在 Console 定位错误，再检查代码变量名修复。
- [ ] **基础安全习惯**：显示不可信文本优先 textContent；理解直接拼接 innerHTML 的风险。
    - **知识讲解**：直接把用户提供的文本插入 innerHTML 可能产生 XSS；默认用 textContent 显示文字，确需 HTML 时用可信模板和安全处理。
    - **跟练任务**：让活动标题等于“<b>活动</b>”，分别使用 textContent 和 innerHTML 查看差异，并说明风险。
#### 本阶段配套综合实战

**不依赖框架完成搜索**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```js
const events = [{id:1,title:'图论训练'}, {id:2,title:'动态规划入门'}];
const input = document.querySelector('#keyword');
const list = document.querySelector('#result');
function render(keyword='') {
  const found = events.filter(e => e.title.includes(keyword.trim()));
  list.replaceChildren();
  if (!found.length) { list.textContent = '暂无匹配活动'; return; }
  for (const event of found) {
    const li = document.createElement('li');
    li.textContent = event.title;
    list.append(li);
  }
}
input.addEventListener('input', () => render(input.value));
render();
// 在 HTML 中准备 <input id="keyword"> 与 <ul id="result"></ul>
```

**练习步骤**

1. 先在 HTML 放 id="keyword" 的 input 和 id="result" 的 ul。
2. 复制 JS 并测试空关键字、正常命中、无命中。
3. 添加 localStorage 记住关键词，并解释它不是后端。

**思考题**：为什么优先使用 textContent 而不是直接拼 innerHTML？
**参考答案**：textContent 会把不可信输入作为文本处理，不会将其解析成可执行 HTML。

**实战作品**：可搜索活动列表：分类过滤、关键词搜索、加载/空状态、失败提示、localStorage 收藏。
**验收清单**
- [ ] 搜索无结果时有明确提示
- [ ] 模拟接口失败也不会白屏
- [ ] 刷新后收藏保留；能解释存储在哪台设备
**常见错误**：直接让 AI 写复杂状态管理；只跑正常数据；把 localStorage 当成共享数据库。
**推荐资料**：[现代 JavaScript 教程（中文）](https://zh.javascript.info/)、[MDN：Web 核心学习（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core)、[MDN：HTTP 概述（中文）](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Guides/Overview)

### 04｜第 7–8 周 · 协作、调试与首次上线
**目标**：能把静态/纯前端项目放进 GitHub，协作修改、测试并上线。
**知识点 / 掌握标准**
- [ ] **终端基础**：熟悉 pwd/cd/ls 与 Windows 对应操作，理解当前目录和相对路径。
    - **知识讲解**：终端命令在“当前工作目录”运行；cd 切目录，pwd/Windows cd 看位置，ls/dir 查看文件。路径错误是初学者常见原因。
    - **跟练任务**：在项目文件夹打开终端，用 pwd（PowerShell 可用 pwd）、ls 或 dir 确认能看到 index.html。
- [ ] **Git 三层概念**：区分工作区、暂存区和提交记录，会用 status、add、commit、log。
    - **知识讲解**：Git 工作区是正在改的文件，暂存区决定本次提交内容，commit 形成可追溯快照；status 给出当前状态。
    - **跟练任务**：修改一行 CSS，依次运行 git status、git add、git diff --cached、git commit，再看 git log。
- [ ] **GitHub 合作**：会建分支、创建 Pull Request、做代码审查和合并。
    - **知识讲解**：分支让修改隔离，Pull Request 让同伴查看差异并讨论后合并；不要在主分支直接试验大改动。
    - **跟练任务**：建 feature/activity-card 分支，加一张卡片提交，再在 GitHub 发起 PR 让同学 review。
- [ ] **README**：写清项目用途、启动方式、功能、截图、已知限制。
    - **知识讲解**：README 必须回答“这是什么”“怎么启动”“已经实现什么”“有什么限制”，不是只有项目名的展示文案。
    - **跟练任务**：让没参与开发的同学只按 README 运行项目，记录并修补缺失步骤。
- [ ] **npm 和 package.json**：知道依赖、脚本、lockfile 的用途；此阶段不必追逐框架。
    - **知识讲解**：npm 用于安装包和运行 scripts，package.json 声明依赖与命令，lockfile 记录可复现的依赖版本。
    - **跟练任务**：在一个独立练习目录运行 npm init -y，阅读 scripts、dependencies 等字段；不要随意删除 lockfile。
- [ ] **API 与数据流**：看懂 URL、方法、请求头、请求体、响应状态码和 JSON。
    - **知识讲解**：HTTP 请求含方法、地址、头、可选请求体；响应有状态码、头和内容。JSON 是常见正文格式而非传输协议。
    - **跟练任务**：打开浏览器 Network，选一个请求分别标出 Method、Status、Headers 和 Response。
- [ ] **基础浏览器测试**：验证点击、输入、导航、刷新、返回以及不同宽度。
    - **知识讲解**：手测应包含操作顺序和预期结果；“点了一下没报错”不是充分验收。
    - **跟练任务**：写 5 个用例：点导航、筛选活动、清空筛选、刷新、手机浏览，逐一记录结果。
- [ ] **边界与异常**：测试空数据、长标题、断网、404、无效输入。
    - **知识讲解**：边界数据能揭露正常用例没发现的错误，例如空数组、极长标题、断网、重复点击。
    - **跟练任务**：把活动数据改成空数组和 150 字长标题，修复布局和提示。
- [ ] **性能常识**：压缩大图、避免无必要请求，用浏览器 Network 查看大小与耗时。
    - **知识讲解**：首先量再优化：大图尺寸和多余网络请求很常见；Network 能显示传输大小与耗时。
    - **跟练任务**：找出加载最大的两张图片，压缩后比较页面总传输体积。
- [ ] **静态部署**：能通过 GitHub Pages 等静态托管发布网站，知道它不运行数据库服务。
    - **知识讲解**：GitHub Pages 发布 HTML/CSS/JS 静态资源，不负责在服务器上执行 Node API 或运行 PostgreSQL。
    - **跟练任务**：配置 Pages 并拿真实网址在手机打开；记下静态站点的功能边界。
- [ ] **版本与回退**：遇到坏改动能对比 diff 与回退；知道何时不应强推共享分支。
    - **知识讲解**：git diff 比较更改，git log 追踪历史。回退公开分支通常优先考虑 git revert，避免破坏其他人的提交。
    - **跟练任务**：在测试分支做一个明显坏改动，再演练恢复；说明 revert 与 reset 用途有何不同。
- [ ] **调试记录**：提交前留下现象、复现步骤、定位原因、修复和测试证据。
    - **知识讲解**：Bug 记录至少包含环境、现象、复现步骤、预期与实际、定位依据、修改与回归结果。
    - **跟练任务**：把一次图片 404 或布局溢出的修复写成 6 行问题记录附到 README。
#### 本阶段配套综合实战

**从修改到 PR 的最小闭环**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```bash
git status
git switch -c feature/event-search
git add index.html style.css
git diff --cached
git commit -m "feat: add event search layout"
git push -u origin feature/event-search
# 在 GitHub 发 Pull Request，审核后再合并
```

**练习步骤**

1. 先确保已初始化仓库并配置远端。
2. 修改一项真实功能后创建单独提交。
3. 在 PR 里描述如何手动验证，合并后检查线上页面。

**思考题**：为什么构建通过还不足以证明发布成功？
**参考答案**：构建只验证生成产物；还需要打开线上真实 URL、操作页面并检查资源和路由。

**实战作品**：社团活动展示站 v1：真实可点击链接、筛选交互、README、至少两次 PR 变更、公开预览地址。
**验收清单**
- [ ] 另一位同学按 README 能打开/运行项目
- [ ] 至少提交一次有意义的 PR，并说明修改理由
- [ ] 项目上线后用真实手机访问一次
**常见错误**：只让 AI 宣布「测试通过」；没有截图/日志就认为部署成功；把 API 密钥提交到仓库。
**推荐资料**：[Pro Git（中文）](https://git-scm.com/book/zh/v2)、[GitHub Pages：发布教程](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)、[MDN：Web 核心学习（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core)、[MDN：HTTP 概述（中文）](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Guides/Overview)

## 路线 A：仅前端
### F1｜第 9–10 周 · TypeScript 与现代前端工具
**目标**：能创建 Vite 项目，理解 TS 的价值，合理拆分模块并检查类型错误。
**知识点 / 掌握标准**
- [ ] **模块化**：理解 import/export 和 ES modules，区分模块与传统 script。
    - **知识讲解**：ES module 通过 export 暴露成员，import 显式声明依赖，能避免所有函数挂到全局对象造成命名冲突。
    - **跟练任务**：把 filterEvents 提取到 events.js 并 export，在 main.ts 导入使用。
- [ ] **Vite**：会创建与启动项目，知道 dev/build/preview 各命令在做什么。
    - **知识讲解**：Vite 在开发时提供快速本地服务器并支持模块变更；npm run build 生成可部署的静态资源，不等于启动后端。
    - **跟练任务**：用 Vite 创建 vanilla-ts 模板，分别跑 dev/build/preview 并对比地址与 dist。
- [ ] **TypeScript 基础**：会给变量、函数参数/返回值、数组和对象添加类型。
    - **知识讲解**：TypeScript 在编辑和构建时检查类型，最后仍转换为 JavaScript；number 和 string 不应混用。
    - **跟练任务**：给 filterEvents 的 events 与 keyword 参数加类型，故意把数字传给 keyword 看报错。
- [ ] **类型建模**：用 interface/type、可选属性、联合类型表示 API 数据。
    - **知识讲解**：type / interface 描述数据形状；例如 Event 有 id:number、title:string、date?:string 可防止组件误用字段。
    - **跟练任务**：为活动 API 响应定义 Event 类型，把 date 设可选并编译检验。
- [ ] **类型收窄**：会用 typeof、in、判空缩小联合类型，不乱用 any。
    - **知识讲解**：联合类型如 string | null 需要先判空再调用字符串方法，typeof 和 in 可帮助类型收窄。
    - **跟练任务**：写一个参数为 string | undefined 的函数，不使用 !，完成安全判空。
- [ ] **异步数据类型**：把 Promise 与返回数据结构联系起来，处理未知错误类型。
    - **知识讲解**：Promise<Event[]> 表示异步返回活动数组，但并不能保证服务端真返回正确形状；运行时仍需验证未知 JSON。
    - **跟练任务**：声明 async loadEvents():Promise<Event[]>，模拟服务端返回缺失 title 时设计校验逻辑。
- [ ] **格式与静态检查**：接触 ESLint、格式化工具与 TypeScript 检查；知道不同工具的职责。
    - **知识讲解**：Prettier 统一格式，ESLint 发现可疑代码模式，tsc 发现类型问题，测试工具验证实际行为，职责不同。
    - **跟练任务**：配置 format、lint、typecheck、test 四条独立命令，并故意制造类型错误验证检查有效。
- [ ] **配置和环境变量**：理解开发/生产环境区别；前端构建出的变量会暴露，不放服务器机密。
    - **知识讲解**：VITE_ 前缀之类的构建环境变量可能被打包进浏览器代码；密钥属于后端，不应写入客户端 bundle。
    - **跟练任务**：定义一个公开 API 基础地址变量，打包后搜索 dist 看其是否出现在输出中。
- [ ] **构建产物**：能解释 dist、资源哈希、静态资源相对路径和刷新 404 的常见原因。
    - **知识讲解**：dist 中是编译后的前端静态文件；路由刷新 404 往往和主机的 SPA fallback 配置有关。
    - **跟练任务**：本地执行 build+preview，检查图片相对路径和详情页刷新行为。
#### 本阶段配套综合实战

**用 TypeScript 描述活动列表**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```ts
type EventItem = { id: number; title: string; location?: string };
function filterEvents(events: EventItem[], keyword: string): EventItem[] {
  return events.filter(e => e.title.includes(keyword.trim()));
}
const events: EventItem[] = [{id: 1, title: '图论训练'}];
console.log(filterEvents(events, '图论'));
// 故意把第二参数改成 42，观察 TypeScript 类型错误
```

**练习步骤**

1. 用 Vite vanilla-ts 初始化示例项目。
2. 建立 EventItem 类型并将筛选逻辑移动到单独模块。
3. 执行类型检查和 build，并保存一次故意制造类型错误的截图。

**思考题**：TypeScript 类型正确能保证后端返回的 JSON 也正确吗？
**参考答案**：不能；运行时接收到的外部数据仍可能不符合预期，需要在输入边界做校验。

**实战作品**：把第 6 周的活动搜索页迁移成 TypeScript + Vite，保留原有全部功能。
**验收清单**
- [ ] 类型检查/构建命令正常完成
- [ ] 故意把数字传成字符串时能看到类型错误
- [ ] 迁移前后主要交互行为一致
**常见错误**：把 TS 当成「更高级的 JS」就跳过 JS；靠 any 或 @ts-ignore 消除所有错误。
**推荐资料**：[Vite：入门指南](https://vite.dev/guide/)、[TypeScript：官方手册](https://www.typescriptlang.org/docs/handbook/intro)

### F2｜第 11–14 周 · React 或 Vue：组件化 UI
**目标**：能够围绕业务需求拆组件、管理状态、接入路由，而不是只会复制 UI 库示例。
**知识点 / 掌握标准**
- [ ] **框架选择**：React 或 Vue 任选其一；不要前两周两个框架同时学。
    - **知识讲解**：React 的 JSX 和 Vue 的模板采用不同写法，但组件、数据流、状态更新的核心问题相同，先掌握一套。
    - **跟练任务**：在同一社团列表需求里评估两种写法，然后选定一个框架，坚持做完项目。
- [ ] **组件拆分**：把页面拆成导航、活动卡片、筛选器、表单、弹窗等单一职责组件。
    - **知识讲解**：组件的职责应该清晰：EventCard 显示单条活动，EventList 管列表，EventFilter 管搜索；避免单文件塞下所有东西。
    - **跟练任务**：画出首页组件树，并把至少 3 个可复用区域拆为单独组件。
- [ ] **Props**：理解父组件向子组件传数据，不把所有东西塞进全局对象。
    - **知识讲解**：props 是父传子的输入，不应在子组件直接任意修改父状态；例如把 activity 对象传给 EventCard 展示。
    - **跟练任务**：把活动标题与时间以 props 传给卡片，尝试改变父列表看子卡片是否更新。
- [ ] **状态与视图**：掌握 state/ref/reactive 的基本关系，知道更新状态为何会刷新界面。
    - **知识讲解**：React state / Vue ref 让数据变化驱动 UI 重新呈现；直接操作 DOM 可能绕过框架的数据管理。
    - **跟练任务**：用状态变量保存关键词和筛选结果，不再手写 querySelector 改每个卡片的 display。
- [ ] **事件通信**：处理点击和输入，掌握父子之间的交互与状态提升。
    - **知识讲解**：子组件用回调/emit 向父组件报告用户操作，由拥有数据的一层决定如何更新。
    - **跟练任务**：在 EventFilter 中发出 keyword 变化，父组件根据它更新活动列表。
- [ ] **列表与条件渲染**：会稳定渲染列表、处理 key、空状态和加载状态。
    - **知识讲解**：条件渲染决定加载/空/错误时显示何种内容；列表需要稳定唯一 key，不应无理由使用数组序号。
    - **跟练任务**：活动数组为空时显示空状态；列表项用 id 作为 key，并测试新增与删除。
- [ ] **副作用**：能解释何时发请求、订阅与清理；React 关注 effect，Vue 关注 watch/onMounted。
    - **知识讲解**：副作用指发起请求、订阅计时等外部交互，需要考虑触发时机与清理；不能在每次渲染里无限请求。
    - **跟练任务**：在页面进入时加载活动，离开或输入变化时避免过期请求覆盖新结果。
- [ ] **表单**：处理输入、校验、错误显示与提交反馈。
    - **知识讲解**：受控表单明确输入来源与校验状态；反馈要准确区分“尚未提交”“提交中”“提交失败”“成功”。
    - **跟练任务**：写一个报名表单，禁止空姓名提交，显示字段错误而不是简单 alert。
- [ ] **路由**：完成首页/活动列表/活动详情三个页面；理解客户端路由与服务端路由差异。
    - **知识讲解**：客户端路由能在不整页重新加载的情况下切换视图，但服务器要支持直接访问/刷新对应 URL。
    - **跟练任务**：增加 /events 与 /events/:id 两类页面，测试地址栏直接输入详情 URL。
- [ ] **复用逻辑**：按需使用自定义 Hook / Composable，先解决重复问题再抽象。
    - **知识讲解**：自定义 Hook / Composable 用于共享行为逻辑，不能只为“高级”把两行简单代码抽象成多层。
    - **跟练任务**：将至少两页都需要的活动加载逻辑提取为一个复用函数或 Hook。
- [ ] **UI 组件库**：理解引入库的代价；能在不依赖组件库时做基础按钮和表单。
    - **知识讲解**：组件库可省时间但引入体积、样式约束和可访问性负担；基础按钮、表单和卡片应先会自己实现。
    - **跟练任务**：只用基础 CSS 做按钮/表单，再选一个组件库比较包体积和可访问性表现。
- [ ] **调试**：使用框架 DevTools，定位异常渲染与状态来源。
    - **知识讲解**：组件不更新时优先看 props/state 变化路径；React/Vue DevTools 能显示组件树与状态。
    - **跟练任务**：故意让关键字状态不更新，用框架 DevTools 查出数据在哪一层没有传播。
#### 本阶段配套综合实战

**一个 React 组件怎样流动数据**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```tsx
import { useState } from 'react';
const events = [{id: 1, title: '图论训练'}, {id: 2, title: '算法交流'}];
export default function EventList() {
  const [keyword, setKeyword] = useState('');
  const found = events.filter(e => e.title.includes(keyword));
  return <section>
    <label>搜索活动 <input value={keyword}
      onChange={e => setKeyword(e.target.value)} /></label>
    {found.length ? found.map(e => <p key={e.id}>{e.title}</p>)
      : <p>没有匹配活动</p>}
  </section>;
}
// 选 Vue 的学员改用 ref、v-model、v-for 实现等价功能。
```

**练习步骤**

1. 先在纸上画出输入框 → keyword 状态 → 列表的单向更新流程。
2. 实现组件，再拆分 SearchBox 和 EventCard。
3. 实现空状态和路由刷新检查。

**思考题**：为什么不建议在 React 渲染后通过 querySelector 手动隐藏活动卡片？
**参考答案**：会绕开框架状态与渲染模型，使 DOM 与状态不同步；应更新状态然后由框架渲染。

**实战作品**：组件化社团网站：主页、公告列表、活动详情、报名表单（先使用模拟数据）。
**验收清单**
- [ ] 至少复用 3 个通用组件
- [ ] URL 与页面能对应，返回/刷新逻辑正确
- [ ] 能清楚解释某个状态应放在哪个组件
**常见错误**：动不动上全局状态库；还没理解组件就套庞大后台模板。
**推荐资料**：[React：Thinking in React](https://react.dev/learn/thinking-in-react)、[Vue 3：官方中文指南](https://cn.vuejs.org/guide/introduction)、[Vite：入门指南](https://vite.dev/guide/)

### F3｜第 15–17 周 · 前端工程质量
**目标**：交付可靠的前端，而不只是「截图看着不错」。
**知识点 / 掌握标准**
- [ ] **API 交互**：统一封装请求函数，区分业务错误、网络错误和 HTTP 错误。
    - **知识讲解**：接口层单独处理 fetch 的 URL、header、状态检查和 JSON 解析，让组件只关心领域数据与 UI。
    - **跟练任务**：创建 api/events.ts，封装 listEvents()，在组件中只调用函数不拼接 URL。
- [ ] **状态边界**：处理 loading、empty、error、success 及重试逻辑。
    - **知识讲解**：请求通常至少有 idle、loading、success、empty、error 状态；success 可以有数据为空，两者文案不应混淆。
    - **跟练任务**：给活动列表绘制状态转移草图，逐一模拟等待、无结果、500 和正常数据。
- [ ] **错误恢复**：异常不能导致整页不可用；有可读提示和下一步操作。
    - **知识讲解**：出错提示应告诉用户怎么恢复：重试按钮、检查网络、保留旧内容；仅在控制台报错不足以交付。
    - **跟练任务**：断开网络触发 error，提供“重新加载”按钮并验证恢复流程。
- [ ] **输入校验**：前端在提交前给及时提示，但知道真正的权限与安全校验必须靠后端。
    - **知识讲解**：前端校验能减少无效提交，但攻击者可直接调用 API；后端必须重新验证规则和权限。
    - **跟练任务**：实现邮箱格式和必填提示，并说明后端仍要拒绝同样非法的请求。
- [ ] **组件测试**：会测试搜索函数、筛选规则和组件主要交互，不只测试是否能渲染。
    - **知识讲解**：组件测试关注具体交互与输出，例如搜索框输入后是否只显示匹配结果；不要只测渲染没崩。
    - **跟练任务**：写一个测试：输入“图论”后只出现图论活动，输入不存在词显示空状态。
- [ ] **端到端测试**：用 Playwright 或手动脚本覆盖完整用户路径：打开、搜索、查看详情。
    - **知识讲解**：E2E 通过浏览器操作完整路径，覆盖路由、渲染和事件；与单元测试互补而非互相替代。
    - **跟练任务**：用 Playwright 从首页点击活动并返回列表，截图或保存运行报告。
- [ ] **无障碍**：键盘可达、焦点可见、label 正确、图片有意义的 alt。
    - **知识讲解**：无障碍首先是可键盘操作、可识别名称、正确标题与合理对比；动态错误提示最好可被辅助技术感知。
    - **跟练任务**：闭眼不使用鼠标完成活动搜索和详情打开，至少修复一处键盘障碍。
- [ ] **响应式回归**：组件变动后重新检查手机、平板、桌面。
    - **知识讲解**：组件变更可能影响多个尺寸。先检查窄屏最容易溢出的长标题、表单和弹窗，再测平板/桌面。
    - **跟练任务**：每次调整导航后固定回归 360、768、1440px 三种宽度。
- [ ] **性能测量**：用 Lighthouse/Network 分析图片体积、资源加载，优化有明确收益的问题。
    - **知识讲解**：性能优化从测量开始：图片传输体积、关键 JS 资源、请求数量和实际用户感受比随意“上缓存”重要。
    - **跟练任务**：用 Lighthouse 与 Network 对比一次图片尺寸优化前后的结果并记录数值。
- [ ] **数据与视图分离**：用 API 类型/适配层减少服务端字段变化对组件的影响。
    - **知识讲解**：API 字段与 UI 显示不是一回事；用适配函数将后端字段转成前端视图模型，避免每个组件各自处理空值。
    - **跟练任务**：把 start_time 映射为 startTime，把缺失地点转成“待定”，仅在适配层处理。
- [ ] **错误日志**：保留复现步骤、console/Network 证据，能判断前端还是接口异常。
    - **知识讲解**：错误记录应包含可复现步骤与请求状态，而不能包含真实用户密码、令牌等秘密。
    - **跟练任务**：编写“活动页面报错”的 issue 模板，含 URL、操作、状态码、预期/实际。
#### 本阶段配套综合实战

**四种请求状态与失败恢复**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```ts
type LoadState = 'idle' | 'loading' | 'success' | 'error';
async function getEvents(): Promise<unknown> {
  const response = await fetch('/api/events');
  if (!response.ok) throw new Error('HTTP ' + response.status);
  return response.json();
}
// 组件调用前 state='loading'，成功且校验数据后更新为 success；
// 失败则更新为 error 并显示可点击的“重试”。
// 空数组需要单独显示“暂时没有活动”，不能冒充网络失败。
```

**练习步骤**

1. 实现加载中、正常数据、无结果、错误四种 UI。
2. 使用 DevTools 网络断开模拟失败，验证重试按钮有效。
3. 写一条单元测试验证筛选逻辑，一条 E2E 验证搜索流程。

**思考题**：服务器返回 404 会自动让 fetch 进入 catch 吗？
**参考答案**：fetch 对普通 HTTP 404 通常返回 Response；需要检查 response.ok 后主动抛错。

**实战作品**：社团活动信息台：真实公开 API 或受控模拟 API、搜索/分页/重试、可靠错误提示和测试。
**验收清单**
- [ ] 断网情况下页面有可操作的恢复方式
- [ ] 至少 5 个关键用例有测试记录
- [ ] 明确区分自己前端负责的行为与 API 负责的行为
**常见错误**：把后端数据库、账号权限都写成「前端功能」；只测正常数据路径。
**推荐资料**：[MDN：Web 无障碍（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core/Accessibility)、[Vitest：官方入门](https://vitest.dev/guide/)、[Playwright：官方文档](https://playwright.dev/docs/intro)、[web.dev：Learn Performance](https://web.dev/learn/performance)

### F4｜第 18–20 周 · 前端毕业项目与作品集
**目标**：上线一个可解释、可维护、可访问的中等复杂度前端作品。
**知识点 / 掌握标准**
- [ ] **需求说明**：能把模糊想法拆成功能清单、页面清单和验收项。
    - **知识讲解**：需求要可验收；“页面高级”不可验证，“手机不横向溢出并支持搜索与详情”可验证。
    - **跟练任务**：写 8 条功能需求并为每条定义操作与预期结果。
- [ ] **信息架构**：画出导航结构与页面之间的关系。
    - **知识讲解**：信息架构说明页面和入口的关系；用户应该能预测点击导航后到哪里，避免跳转混乱。
    - **跟练任务**：画首页→活动列表→活动详情→资料页的页面关系图。
- [ ] **组件规划**：挑出复用组件，解释拆分原则和文件布局。
    - **知识讲解**：组件规划从重复内容和变化点出发，通用组件稳定，业务组件负责自身领域，不为复用而复用。
    - **跟练任务**：列出组件树并圈出至少 3 个实际复用的组件。
- [ ] **设计一致性**：统一按钮、颜色、字体、间距与表单状态。
    - **知识讲解**：设计一致性来自少量颜色、排版和间距规则，而不是所有元素都加动画和渐变。
    - **跟练任务**：写一个 design-tokens.css，统一按钮高度、卡片圆角和正文色。
- [ ] **真实数据策略**：公开 API、模拟 API 或本地文件合理选型，并注明数据来源。
    - **知识讲解**：公开 API、受控 mock、本地 JSON 各有适用场景。mock 必须标注演示数据，不能冒充实时真实数据。
    - **跟练任务**：为每个页面注明数据来源，移除“假的报名成功/真实用户数”误导。
- [ ] **错误与空态**：每个重要页面都有加载、为空、失败的表现。
    - **知识讲解**：所有重要组件要考虑加载、为空、失败；例如空列表不是报错，用户应该知道下一步能做什么。
    - **跟练任务**：把网络断开并把返回活动设空，分别展示两套不同提示。
- [ ] **单元与 E2E**：为关键逻辑编写测试，保留运行说明。
    - **知识讲解**：单元测试保护筛选排序等逻辑，E2E 检验浏览器流程；测试要包括失败场景。
    - **跟练任务**：选三个核心流程，各写输入、预期和证据位置；至少实现一个自动化测试。
- [ ] **部署与回滚**：构建并部署静态前端，能回退到可用版本。
    - **知识讲解**：前端发布要保证构建产物与路由配置正确；回滚应能恢复上一可用版本，不只提交新代码。
    - **跟练任务**：部署两次版本，演练回退一次，验证旧页面链接仍可访问。
- [ ] **作品集陈述**：README 讲清目标、技术权衡、本人负责部分和限制。
    - **知识讲解**：作品集展示真实能力：目标、方案、权衡、遇到的 Bug 和你亲手解决的细节，比技术栈堆叠更有说服力。
    - **跟练任务**：在 README 加上技术选择理由、项目截图与两项实际修复记录。
- [ ] **演示与复盘**：准备 3 分钟演示：问题→方案→功能→遇到的问题→改进。
    - **知识讲解**：好的演示讲清用户问题和证据，不把“用了 AI”视为功能本身；限制要明确。
    - **跟练任务**：准备 3 分钟演示脚本，现场演示一次错误恢复而不仅是成功截图。
#### 本阶段配套综合实战

**把产品目标写成可验收功能**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```md
## 功能：活动筛选
前提：列表中有图论、动态规划活动
操作：输入“图论”
预期：只出现图论训练，页面不重载
空数据：输入不存在关键词显示“没有匹配活动”
失败：API 500 显示错误与“重试”按钮
证据：tests/search.spec.ts、screenshots/360.png
```

**练习步骤**

1. 把首页、列表、详情划分为页面与可复用组件。
2. 逐条写下真实功能的输入、输出和异常路径。
3. 做现场演示，公开承认尚未实现的服务端功能。

**思考题**：演示“假的报名成功弹窗”能算实现报名功能吗？
**参考答案**：不能。没有服务端记录或实际连接时应明确标注“界面演示”，不能误导用户。

**实战作品**：「社团活动与资料展示平台」前端版：多页面、筛选/收藏、响应式、无障碍和测试；数据可来自可靠外部 API 或 mock。
**验收清单**
- [ ] 提供可访问的演示地址、源码地址、README
- [ ] 核心流程在 PC 与手机实测可用
- [ ] 能独立修改一个新增需求并说明测试结果
**常见错误**：为了「全栈感」去自建没有必要的后台；用假按钮或摆设功能充数。
**推荐资料**：[React：Thinking in React](https://react.dev/learn/thinking-in-react)、[Vue 3：官方中文指南](https://cn.vuejs.org/guide/introduction)、[MDN：Web 无障碍（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core/Accessibility)、[GitHub Pages：发布教程](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)

## 路线 B：全栈
### S1｜第 9–11 周 · 前端框架与 TypeScript
**目标**：能构建一个读取 API 的组件化前端，理解它与后端之间的协议。
**知识点 / 掌握标准**
- [ ] **框架二选一**：在 React 与 Vue 中选一种完成首个项目，不并行学习。
    - **知识讲解**：全栈不等于不用前端。选一套框架理解组件、路由与状态，后端返回的数据最终仍要被正确展示。
    - **跟练任务**：在 React/Vue 中选一种，画出社团首页三组件的关系。
- [ ] **Vite/模块**：使用开发服务器、npm 脚本、import/export 管理代码。
    - **知识讲解**：import/export 组织模块，Vite 提供开发与构建；不要把 npm run dev 误认为上线生产后端。
    - **跟练任务**：建立 Vite 项目并拆出 EventCard 模块，跑 build 确认产物。
- [ ] **TypeScript 基础**：类型、接口、函数和 API 响应数据建模。
    - **知识讲解**：TS 类型帮助编辑器提前发现 id 数字/字符串等错误，但外部 API 数据需要运行时校验。
    - **跟练任务**：定义 Event 接口并在组件中使用，模拟不符合形状的服务端响应。
- [ ] **组件拆分**：页面拆为列表、详情、表单、消息提示等模块。
    - **知识讲解**：职责清晰的组件减少耦合：列表、详情、表单、状态提示可以分别维护。
    - **跟练任务**：把单页改成四个组件，再改活动卡片视觉验证没有重复修改多处。
- [ ] **状态与事件**：区分组件内状态、共享状态与后端持久数据。
    - **知识讲解**：表单 state 保存用户输入，后端保存持久结果，二者生命周期不同；不能把 localStorage 当作可靠共享数据。
    - **跟练任务**：页面提交后重新请求活动数据而不是永远只更新浏览器变量。
- [ ] **路由**：理解前端路由和后端路由，各自处理哪些 URL。
    - **知识讲解**：前端路由选择哪个组件显示，API 路由决定后端如何处理请求，二者常分别使用 /events 和 /api/events。
    - **跟练任务**：画出 /events 和 /api/events 各走哪部分代码，并在 Network 验证。
- [ ] **fetch 调用**：会向模拟 API 请求，并处理成功、失败、超时/断网情形。
    - **知识讲解**：fetch 需要检查 response.ok，处理 JSON 格式和失败状态；开发代理可以避免不必要的路径混乱。
    - **跟练任务**：从受控 mock API 拉取活动，分别测试成功和 500。
- [ ] **表单校验**：向用户显示错误，知道后端仍须独立校验。
    - **知识讲解**：页面校验改善体验，安全的最终判定在后端；不要只禁用按钮就认为权限被保护。
    - **跟练任务**：让姓名为空时报错，同时写出后端必须检查的同一规则。
- [ ] **浏览器调试**：使用 Network 报文验证真实请求，不猜接口行为。
    - **知识讲解**：Network 中会真实显示请求方法、URL、Body、状态码与响应体，定位联调时比猜测快。
    - **跟练任务**：提交表单后截图保存 Request Payload 与 Response，确认数据正确。
- [ ] **环境变量**：明白公开前端配置与服务器秘密配置的差别。
    - **知识讲解**：前端能看到的任何字符串都应按公开信息看待。数据库口令、签名密钥只能留在服务器环境配置中。
    - **跟练任务**：打包生产 bundle 并搜索公开环境变量，验证没有数据库密码。
#### 本阶段配套综合实战

**区分前端状态和服务器数据**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```ts
type EventItem = { id: number; title: string };
async function listEvents(): Promise<EventItem[]> {
  const res = await fetch('/api/events');
  if (!res.ok) throw new Error('活动加载失败');
  // 实际项目仍需对外部 JSON 做运行时校验
  return await res.json() as EventItem[];
}
// 前端输入框的当前关键词是临时 UI state；
// 活动记录最终由 API 与数据库负责持久化。
```

**练习步骤**

1. 选择 React 或 Vue 完成搜索、列表、详情基本框架。
2. 用模拟 API 将前端活动与服务器数据区分开。
3. 在 Network 明确指出哪个请求来自真实服务器。

**思考题**：把管理员按钮隐藏后，普通用户是否就没有权限调用管理员接口？
**参考答案**：不是。隐藏只影响 UI；真正权限必须由后端对每个受保护请求进行验证。

**实战作品**：建立组件化活动管理前端，暂用模拟接口；后续不重写 UI，直接对接自己开发的后端。
**验收清单**
- [ ] 能用示意图画出组件→API→服务端的数据流
- [ ] 模拟 API 出错时不白屏
- [ ] 能说明前端无法单独实现可靠的管理员权限
**常见错误**：认为「全栈」就是跳过前端；使用前端隐藏按钮作为权限控制。
**推荐资料**：[Vite：入门指南](https://vite.dev/guide/)、[TypeScript：官方手册](https://www.typescriptlang.org/docs/handbook/intro)、[React：Thinking in React](https://react.dev/learn/thinking-in-react)、[Vue 3：官方中文指南](https://cn.vuejs.org/guide/introduction)

### S2｜第 12–14 周 · HTTP、服务端与 REST API
**目标**：用 Node.js + Express（或 Python + FastAPI）做出规范、可测试的 API。
**知识点 / 掌握标准**
- [ ] **请求/响应模型**：区分浏览器、网络、Web 服务器、应用逻辑与数据库。
    - **知识讲解**：浏览器构造请求；服务器按路由和业务规则计算；数据库持久化；服务端再返回状态与 JSON。各层有清晰的边界。
    - **跟练任务**：画出点击“创建活动”后从浏览器到服务器返回的 5 个步骤。
- [ ] **路由与方法**：设计 GET/POST/PATCH/DELETE 的合理用途与 URL。
    - **知识讲解**：GET 读资源，POST 常用于创建，PATCH 部分更新，DELETE 删除；URL 用名词例如 /api/events/12。
    - **跟练任务**：设计 /api/events 的 CRUD 表，写出每个方法、路径、成功码。
- [ ] **状态码**：理解 200/201/204/400/401/403/404/409/500 的典型场景。
    - **知识讲解**：200 通常表示成功返回，201 创建，204 无响应体；400 请求不合法、401 未认证、403 无权、404 不存在、500 服务器错误。
    - **跟练任务**：为“缺少标题”“活动不存在”“普通用户删活动”分别选合适状态码。
- [ ] **JSON 请求体**：接收、解析和返回 JSON；正确设置 Content-Type。
    - **知识讲解**：express.json() 解析 JSON 请求体；Content-Type:application/json 声明发送类型。缺少字段必须返回错误而非默默保存空值。
    - **跟练任务**：用 curl -H "Content-Type: application/json" -d ... 测试 POST 接收的数据。
- [ ] **输入校验**：对必填项、长度、类型、格式进行服务端校验。
    - **知识讲解**：服务端必须校验结构、字符串长度和业务约束；仅检查 input.required 不够，因为客户端可以绕过。
    - **跟练任务**：用 Postman/curl 跳过页面，直接传空标题，确保后端返回 400。
- [ ] **后端分层**：区分路由、控制器/处理器、业务逻辑、数据访问。
    - **知识讲解**：路由层接收 HTTP，服务层处理业务，数据层负责读写；小项目可先简单拆开，避免一个函数包办所有逻辑。
    - **跟练任务**：把“活动标题不能为空”的检查抽成业务函数，编写单元测试。
- [ ] **异步 I/O**：理解服务器读库/文件时的等待和异常处理。
    - **知识讲解**：await I/O 时线程不应被昂贵同步任务阻塞；Promise 拒绝要被 try/catch 或错误中间件处理。
    - **跟练任务**：在查询函数里模拟 reject，验证 API 返回统一错误而不是让进程退出。
- [ ] **环境配置**：使用 .env 等方式保存配置，不把机密写进公开仓库。
    - **知识讲解**：PORT、数据库连接参数等通过服务器环境变量配置；仓库放 .env.example，真实 .env 不进 Git。
    - **跟练任务**：建立 .env.example，仅含变量名与无秘密示例值，确认 git status 不出现本地密钥。
- [ ] **CORS**：明白跨域是浏览器的访问约束，不是登录机制或安全授权。
    - **知识讲解**：CORS 决定浏览器是否允许跨源脚本读取响应，并不能防止 curl、服务器程序直接调用 API；鉴权是另一回事。
    - **跟练任务**：用浏览器和 curl 分别访问接口，解释为什么设置 CORS 不是权限控制。
- [ ] **错误处理**：规范错误响应格式；不直接把堆栈、SQL、密钥暴露给客户端。
    - **知识讲解**：给用户错误信息但不泄漏堆栈或 SQL；错误处理中间件统一转成 {error:{code,message}}。
    - **跟练任务**：制造服务端异常，检查浏览器响应只含通用可理解提示，日志内部可定位。
- [ ] **接口测试**：用 curl/HTTP 客户端发送请求，验证非法输入和不存在资源。
    - **知识讲解**：接口可以独立测试，不依赖前端。用 curl 发送合法、缺字段、非法 ID、重复创建等请求。
    - **跟练任务**：完成一组 5 条 curl 用例并记录请求、响应状态和预期。
- [ ] **API 契约**：写接口文档：字段、示例、失败码；前后端依据契约协作。
    - **知识讲解**：接口契约是前后端协作协议：路径、方法、参数、成功样例与错误样例要一致；OpenAPI 也是选项。
    - **跟练任务**：为活动 GET/POST 接口各写请求示例、200/201 数据、400 错误返回。
#### 本阶段配套综合实战

**Express：活动接口（教学版）**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```js
import express from 'express';
const app = express();
app.use(express.json());
const events = [{id:1,title:'图论训练'}];
app.get('/api/events', (req,res) => res.json(events));
app.post('/api/events', (req,res) => {
  if (typeof req.body?.title !== 'string' || !req.body.title.trim())
    return res.status(400).json({error:'标题不能为空'});
  const item = {id:events.length+1,title:req.body.title.trim()};
  events.push(item);
  res.status(201).json(item);
});
app.listen(3000);
// 教学示例：内存数据重启即消失，且尚无认证、授权和完整校验。
```

**练习步骤**

1. 单独新建后端项目，安装 express 并设置 type:module。
2. 使用 curl 测试 GET、合法 POST 和标题为空的 POST。
3. 记录重启后数据消失的事实，为下一阶段 SQL 铺垫。

**思考题**：为什么不能把示例 Express POST 接口直接开放给真实用户？
**参考答案**：它还缺少鉴权、授权、速率限制、充分校验与持久化，仅为教学演示。

**实战作品**：活动 API v1：新增活动、列表、按 ID 查询、编辑、删除；先用内存数据理解流程。
**验收清单**
- [ ] 正确区分 400、404 和 500 等错误
- [ ] 非法数据会被后端拒绝而不只是页面上提示
- [ ] 只启动后端也能独立调用接口完成 CRUD
**常见错误**：没有学 HTTP 就盲上 Next.js 全栈魔法；把 CORS 配置误当权限控制。
**推荐资料**：[MDN：HTTP 概述（中文）](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Guides/Overview)、[Node.js：官方学习文档](https://nodejs.org/learn/getting-started/introduction-to-nodejs)、[Express：Hello World 与路由](https://expressjs.com/en/starter/hello-world/)、[FastAPI：官方中文教程](https://fastapi.tiangolo.com/zh/tutorial/)

### S3｜第 15–17 周 · 数据库与数据建模
**目标**：能独立设计简单关系表、写 SQL，避免把用户数据散放在 JSON 文件里。
**知识点 / 掌握标准**
- [ ] **关系数据库**：理解表、行、列、主键、外键与唯一约束。
    - **知识讲解**：主键唯一标识行，外键表达引用关系。活动与报名是 1:N 关系，报名表需要 event_id 引用活动。
    - **跟练任务**：画 events、members、registrations 三张表并标出主键/外键。
- [ ] **基本 SQL**：会 CREATE TABLE、INSERT、SELECT、UPDATE、DELETE。
    - **知识讲解**：INSERT 加数据，SELECT 查数据，UPDATE 改数据，DELETE 删除；写操作必须留意 WHERE，避免修改全表。
    - **跟练任务**：在独立测试库写三条活动，SELECT 验证，再只 UPDATE 一条活动标题。
- [ ] **WHERE/ORDER/LIMIT**：完成过滤、排序和分页的数据库查询。
    - **知识讲解**：WHERE 过滤、ORDER BY 排序、LIMIT/OFFSET 分页；服务端不能无上限返回几十万条记录。
    - **跟练任务**：写一条查询：取最近 10 个未来活动，按开始时间排序。
- [ ] **JOIN**：理解一对多/多对多关系；活动与报名记录如何关联。
    - **知识讲解**：JOIN 用关联键连接表；1:N 记录重复可能造成意外计数，需要明确统计语义。
    - **跟练任务**：JOIN 活动和报名表，查询每个活动的报名人数并验证为 0 的活动。
- [ ] **索引**：知道索引有助于查询，也会占空间与增加写入成本。
    - **知识讲解**：索引适合常过滤/关联的列，但增加写入维护与占用空间；先用执行计划定位慢查询再建索引。
    - **跟练任务**：为 registrations.event_id 建索引，比较查询计划而非凭感觉宣称提速。
- [ ] **约束与一致性**：使用 NOT NULL、UNIQUE、FOREIGN KEY 防止脏数据。
    - **知识讲解**：数据库约束是底线：NOT NULL 不许空，UNIQUE 保证唯一，FOREIGN KEY 防止引用不存在的父记录。
    - **跟练任务**：为 (member_id,event_id) 加 UNIQUE，尝试重复报名并捕获约束错误。
- [ ] **事务**：用事务处理多步骤修改，解释全部成功或全部回滚。
    - **知识讲解**：事务把一组操作变成“全部成功或全部回滚”；报名扣名额与生成记录需要一致。
    - **跟练任务**：故意在事务第二步制造错误，确认前一步的数据也回滚。
- [ ] **迁移**：理解 schema 版本升级和数据迁移，不靠删库重建做更新。
    - **知识讲解**：schema 迁移记录数据库结构变化；上线不能简单删掉表重建，否则丢失数据。
    - **跟练任务**：从 events 添加 location 字段，写一次迁移并在已有数据环境验证。
- [ ] **参数化查询**：避免字符串拼接用户输入造成 SQL 注入。
    - **知识讲解**：参数化 SQL 把用户输入当数据而非 SQL 语法的一部分，是防止注入的核心策略。
    - **跟练任务**：用占位符查询标题关键字，试输入引号等特殊字符，确保不改变查询结构。
- [ ] **数据访问层**：把 SQL/ORM 调用从路由处理逻辑中拆开。
    - **知识讲解**：路由关注 HTTP，数据层负责 SQL/ORM 查询，方便测试和以后替换存储技术。
    - **跟练任务**：将“按 id 查活动”的 SQL 移到 repository 文件，路由仅调用函数。
- [ ] **数据库选型**：本地练习可用 SQLite；多人在线部署可学习 PostgreSQL。
    - **知识讲解**：SQLite 适合单机教学与轻量存储；PostgreSQL 更适合多人共享在线服务和复杂并发，需要按需求选型。
    - **跟练任务**：在项目说明中写出为何当前选 SQLite，何时准备迁往 PostgreSQL。
- [ ] **备份和恢复**：知道备份必须验证可恢复，不能只复制一个随时被写入的文件。
    - **知识讲解**：备份不是复制按钮；必须明确备份时机、文件位置、保留策略，并验证能够恢复到一个全新实例。
    - **跟练任务**：制作测试库备份，删除临时实例后从备份恢复，检查活动数量与记录。
#### 本阶段配套综合实战

**把报名规则交给数据库约束**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```sql
CREATE TABLE events (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL
);
CREATE TABLE registrations (
  id INTEGER PRIMARY KEY,
  event_id INTEGER NOT NULL REFERENCES events(id),
  member_id INTEGER NOT NULL,
  UNIQUE(event_id, member_id)
);
-- PostgreSQL / SQLite 中具体键约束行为应依据配置核实。
```

**练习步骤**

1. 建立 events 和 registrations 表，新增三条测试记录。
2. 尝试同成员重复报同活动，观察 UNIQUE 错误。
3. 在后端实现参数化查询，并重启确认数据保留。

**思考题**：为什么只有应用层判断“不能重复报名”还不够？
**参考答案**：并发请求可能同时通过应用层检查；数据库 UNIQUE 约束是最终一致性底线之一。

**实战作品**：活动、成员、报名记录三张关联表；接口从内存数据改为数据库持久化。
**验收清单**
- [ ] 重启后端后数据仍然存在
- [ ] 同一用户不能重复报名同一活动（约束生效）
- [ ] 对非法输入使用参数化 SQL 或框架安全绑定
**常见错误**：ORM 会用就认为理解数据库；把用户输入直接拼接进 SQL；所有信息塞进一张大表。
**推荐资料**：[PostgreSQL：官方 SQL 教程](https://www.postgresql.org/docs/current/tutorial.html)、[OWASP Top 10（2025）](https://top10.owasp.org/2025/0x00_2025-Introduction/)

### S4｜第 18–20 周 · 鉴权、权限与 Web 安全
**目标**：区分认证和授权，能设计最小权限并完成基本安全校验。
**知识点 / 掌握标准**
- [ ] **认证 vs 授权**：登录回答「你是谁」；权限回答「你能做什么」。
    - **知识讲解**：认证确定当前请求来自谁，授权决定这个人可做什么；“已登录”不等于“可以编辑任意用户数据”。
    - **跟练任务**：画匿名用户、成员、管理员三种角色的 GET/POST/PATCH/DELETE 权限表。
- [ ] **安全的密码保存**：使用成熟的密码哈希机制，不存明文，不自创加密算法。
    - **知识讲解**：密码只能保存成熟的慢哈希（如 Argon2id）生成的结果与必要参数，不能保存明文或简单 SHA256。
    - **跟练任务**：查阅成熟认证库的哈希与验证接口，确认数据库只出现哈希而不是密码原文。
- [ ] **会话与 Cookie**：了解服务端会话、HttpOnly、Secure、SameSite 的基本用途。
    - **知识讲解**：Cookie 把会话标识随请求带上；HttpOnly 降低 JS 读取风险，Secure 约束 HTTPS，SameSite 可辅助 CSRF 防护。
    - **跟练任务**：在 DevTools 查看测试站 Cookie 属性，解释每项作用与局限。
- [ ] **权限校验**：每个写入/敏感读取接口做服务端身份与角色校验。
    - **知识讲解**：真正授权要在服务器上针对每个受保护资源检查角色与资源所有权，不信任浏览器传来的 role 字段。
    - **跟练任务**：直接调用管理员删除接口，确认普通成员返回 403 而非仅按钮隐藏。
- [ ] **水平越权**：普通用户不能靠改 URL 或 ID 查看/修改别人的记录。
    - **知识讲解**：水平越权是把 URL 的报名 id 改成别人的就可以读取/删除。权限不能仅检查资源 ID 是否存在。
    - **跟练任务**：成员 A 用成员 B 的报名 ID 发起删除请求，验证服务器拒绝。
- [ ] **输入验证**：服务端验证类型、长度、规则；适当处理超大请求体。
    - **知识讲解**：输入验证要检查类型、长度、允许值和请求体大小，避免无效数据和滥用；安全编码不是简单禁用特殊字符。
    - **跟练任务**：提交 10 万字符标题、数组代替字符串，确认后端以 4xx 拒绝。
- [ ] **SQL 注入**：使用参数化查询和 ORM 安全接口，避免拼 SQL。
    - **知识讲解**：SQL 注入来自把输入拼进查询语法；采用参数化绑定，不靠黑名单删除引号。
    - **跟练任务**：检查 SQL 调用是否使用参数绑定，添加包含单引号的正常名字测试。
- [ ] **XSS**：默认对不可信内容作安全输出处理，不直接执行用户提供的 HTML。
    - **知识讲解**：XSS 是不可信数据变成浏览器可执行脚本；输出到网页时使用框架默认转义或 textContent。
    - **跟练任务**：把活动标题设为带标签的字符串，确认页面按文本显示而不执行 HTML。
- [ ] **CSRF**：使用 Cookie 会话时理解跨站请求伪造风险和对应防护。
    - **知识讲解**：浏览器携带 Cookie 时可能遭跨站请求伪造；SameSite、CSRF Token、Origin 检查按应用架构组合。
    - **跟练任务**：在架构笔记说明 Cookie 会话提交表单为何需要 CSRF 防护。
- [ ] **速率限制**：对登录等高风险接口设合理限制，避免无成本暴力尝试。
    - **知识讲解**：登录尝试是高风险接口，限速与告警可提高暴力尝试成本；不能只对单个 IP 一刀切忽略误伤。
    - **跟练任务**：为测试登录接口设计速率限制与重试提示，验证超限响应不泄漏账号存在性。
- [ ] **HTTPS 与秘密**：使用 HTTPS，秘密配置留在服务器，及时轮换泄漏密钥。
    - **知识讲解**：HTTPS 保护传输；服务器密钥不可发到前端代码，泄漏后要轮换；证书失效也会影响线上可用性。
    - **跟练任务**：核对 .gitignore、部署环境变量和构建产物，模拟发现密钥泄漏后的轮换流程。
- [ ] **错误与日志**：日志不记录口令、令牌、敏感隐私；错误不泄漏内部实现。
    - **知识讲解**：日志要能定位接口错误，但不能记录口令、Cookie 值、认证令牌；对外 500 提示不应暴露堆栈。
    - **跟练任务**：登录失败写入时间/错误码，不写用户密码；检查错误响应是否包含数据库连接信息。
- [ ] **依赖风险**：定期检查依赖，避免安装来源不明的包。
    - **知识讲解**：第三方依赖可能引入已知漏洞或供应链风险；升级前检查兼容性和来源，不盲目安装不明包。
    - **跟练任务**：运行 npm audit（或对应语言的依赖审计工具），列出需处理的项并验证升级测试。
#### 本阶段配套综合实战

**权限检查必须执行在服务器**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```js
// 教学伪代码，不能直接运行：req.user 必须由成熟的认证中间件建立
function requireAdmin(req, res, next) {
  if (!req.user) return res.sendStatus(401);
  if (req.user.role !== 'admin') return res.sendStatus(403);
  next();
}
app.delete('/api/events/:id', authenticate, requireAdmin, deleteEvent);
// 同时要校验资源所有权和请求数据，真实项目采用安全库。
```

**练习步骤**

1. 画普通成员与管理员的权限矩阵。
2. 用测试会话分别请求受保护 API，检查 401/403 的差别。
3. 增加尝试修改别人报名记录的越权案例。

**思考题**：已登录的 A 把请求里的 memberId 改成 B 后，服务器应该检查什么？
**参考答案**：检查该资源属于谁，以及当前 A 是否被授权操作 B 的资源，而不是只验证 A 已登录。

**实战作品**：添加普通成员/管理员：管理员管理活动，成员查看与报名；后端强制校验权限。
**验收清单**
- [ ] 未登录不能访问受保护写入接口
- [ ] 成员直接请求管理员接口返回适当拒绝
- [ ] 改动别人的报名 ID 不会越权成功
**常见错误**：只在前端隐藏按钮；把 JWT 当成一键安全；自写密码加密；忽略越权测试。
**推荐资料**：[OWASP Top 10（2025）](https://top10.owasp.org/2025/0x00_2025-Introduction/)、[Express：Hello World 与路由](https://expressjs.com/en/starter/hello-world/)、[FastAPI：官方中文教程](https://fastapi.tiangolo.com/zh/tutorial/)

### S5｜第 21–24 周 · 联调、测试、部署与运维
**目标**：独立完成前端+API+数据库的部署、验收与基本维护。
**知识点 / 掌握标准**
- [ ] **联调定位**：能区分前端逻辑、网络、API 和数据库层发生的故障。
    - **知识讲解**：请求链路跨浏览器、网络、应用、数据库；先用 Network 确认请求是否发出，再看服务器日志与 SQL。
    - **跟练任务**：制造一例 API 500，从 Network、后端日志、数据库连接逐层确认问题归属。
- [ ] **测试金字塔**：理解单元、接口、端到端测试各自覆盖的风险。
    - **知识讲解**：单元测试检查小函数，接口测试检查服务合同，E2E 检查用户流程；越靠上越完整但通常更慢更难定位。
    - **跟练任务**：为“报名活动”画一张三层测试矩阵，给每层至少两个案例。
- [ ] **接口自动化**：覆盖正常 CRUD、参数错误、未登录、权限不足与不存在 ID。
    - **知识讲解**：接口自动化必须覆盖成功与失败：字段错误、未登录、越权、找不到资源、重复报名。
    - **跟练任务**：编写用例断言：POST /api/events 空标题返回 400，不只检查“有返回”。
- [ ] **E2E**：从登录到报名再到取消报名跑一次完整流程。
    - **知识讲解**：E2E 要模拟真实用户连续操作，关注浏览器和服务组合；可以保留截图/trace 辅助复现。
    - **跟练任务**：用 Playwright 完成登录→打开活动→报名→取消报名的完整链路。
- [ ] **数据库隔离**：测试使用独立数据库/测试数据，不能污染生产环境。
    - **知识讲解**：测试应使用单独数据库，避免覆盖真实报名记录；测试结束后清理数据或重建测试环境。
    - **跟练任务**：确保 TEST_DATABASE_URL 指向独立库，故意失败时核对生产库未被改写。
- [ ] **环境管理**：区分开发、测试、生产环境和不同配置。
    - **知识讲解**：开发、测试、生产各自有独立配置与数据；线上调试不要默认开启详细错误堆栈或弱安全选项。
    - **跟练任务**：建立一张配置表列出不同环境的数据库地址、CORS 与日志级别。
- [ ] **部署架构**：能够画出浏览器→前端托管→后端服务→数据库。
    - **知识讲解**：部署通常拆为静态前端、后端进程、数据库三部分；可在同一服务器也可分开托管。
    - **跟练任务**：画实际公网访问图，标出前端域名、/api 路径、后端端口和数据库连接。
- [ ] **域名/HTTPS**：理解 DNS、证书和反向代理的基本职责。
    - **知识讲解**：DNS 把域名指向服务器；HTTPS 证书证明加密连接；反向代理可转发路径并终止 TLS。
    - **跟练任务**：解释访问 https://example.com/api/events 时请求经过哪几层，不需要立即学 Nginx 全部参数。
- [ ] **日志与监控**：记录关键错误及健康检查信息，能查看服务是否正常。
    - **知识讲解**：健康检查用于判断服务状态，日志帮助定位错误；监控应包含成功率、延迟和错误变化，而不只看 CPU。
    - **跟练任务**：添加不泄漏内部详情的 /health 接口，模拟数据库不可用时的告警与日志。
- [ ] **数据备份**：有备份与恢复演练，明确数据丢失风险。
    - **知识讲解**：备份只有成功恢复过才可信；演练应记录时间点、恢复步骤、数据完整性与可接受损失。
    - **跟练任务**：恢复一次演示数据备份，抽查活动和报名的主外键关系。
- [ ] **发布回滚**：上线前备份/迁移检查，失败能恢复旧版。
    - **知识讲解**：发布前检查迁移兼容性和回滚方案；含数据库破坏性变更时，回滚不只是切 Git commit。
    - **跟练任务**：演练新版本失败：回退应用代码，评估数据库迁移能否安全回退。
- [ ] **CI 基础**：push / PR 时自动执行构建、检查和核心测试。
    - **知识讲解**：CI 可以在 PR 自动运行 lint、typecheck、build、test；工作流成功不保证线上业务百分百正确。
    - **跟练任务**：写一个 GitHub Actions 工作流，提交破坏测试的修改，确认 PR 会失败。
- [ ] **文档与交接**：README、环境变量样例、API 文档、上线/回滚说明完整。
    - **知识讲解**：文档需要包括启动、环境变量模板、API 合同、迁移、上线和恢复步骤，让未参与开发者也能接手。
    - **跟练任务**：把项目交给另一名同学，仅按文档从零启动并记下缺失步骤。
- [ ] **容量与成本意识**：了解免费额度、后端休眠、数据库连接数、存储与带宽费用。
    - **知识讲解**：上线成本包括计算、数据库、存储、带宽、流量与服务休眠；免费额度并不等于无限资源。
    - **跟练任务**：列出预期用户数、图片大小、月流量与托管方案，用估算表解释选择。
#### 本阶段配套综合实战

**让 CI 拒绝错误提交**：下面为教学案例代码，依照注释补齐必要项目结构；不代表可直接部署生产。

```yaml
name: verify
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '22'
          cache: 'npm'
      - run: npm ci
      - run: npm run lint --if-present
      - run: npm test --if-present
      - run: npm run build --if-present
# 项目应提供真实 test 脚本；--if-present 会跳过缺失项，不能当成已有测试。
```

**练习步骤**

1. 配置 lint、测试、构建命令，并确保核心测试脚本真实存在。
2. 故意让测试失败，检查 PR 阻断且能看到日志。
3. 制作数据库备份恢复演练并写上线回滚流程。

**思考题**：GitHub Actions 全部绿色能保证数据库备份可恢复吗？
**参考答案**：不能。必须独立做一次实际恢复测试，验证业务数据完整性。

**实战作品**：社团活动管理系统全栈版：成员账号、管理员、活动与报名数据库、部署、自动化测试、备份说明。
**验收清单**
- [ ] 从空环境按文档能够启动项目
- [ ] 至少验证登录/越权/空数据/断网/异常输入/数据库持久化
- [ ] 提供真实在线演示与部署说明（机密不入库）
**常见错误**：只看构建通过，不测线上功能；把生产数据库当测试库；把「能访问」当成安全验收。
**推荐资料**：[Playwright：官方文档](https://playwright.dev/docs/intro)、[Vitest：官方入门](https://vitest.dev/guide/)、[OWASP Top 10（2025）](https://top10.owasp.org/2025/0x00_2025-Introduction/)、[Node.js：官方学习文档](https://nodejs.org/learn/getting-started/introduction-to-nodejs)

## 6 段最小代码示例（用于理解，不是完整项目）
### HTML 语义化骨架
结构是内容的意义，不是外观；不要只为了样式把一切都写成 div。
```html
<header><nav aria-label="主导航"><a href="#events">活动</a></nav></header>
<main>
  <section id="events" aria-labelledby="events-title">
    <h2 id="events-title">近期活动</h2>
    <article><h3>算法训练营</h3><p>每周六晚上</p></article>
  </section>
</main>
```

### CSS 响应式卡片
minmax 和 auto-fit 不需要记固定的「手机型号」，更关注内容容不容得下。
```css
.cards {display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:20px}
.card {padding:20px;border:1px solid #ddd;border-radius:12px}
img {max-width:100%;height:auto}
```

### JavaScript：可靠的 fetch
请求失败不只有网络断开；HTTP 404/500 也必须主动判断 response.ok。
```js
async function loadEvents() {
  try {
    const response = await fetch('/api/events');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const events = await response.json();
    renderEvents(events); // 你自己实现渲染逻辑
  } catch (error) {
    showError('加载失败，请稍后重试');
    console.error(error);
  }
}
```

### Express：一个最小 API
后端才可以决定谁能访问真实数据；以下只用于解释路由，不是完整生产系统。
```js
import express from 'express';
const app = express();
app.use(express.json());
app.get('/api/events', (req, res) => {
  res.json([{id: 1, title: '算法训练营'}]);
});
app.listen(3000);
```

### SQL：关系与约束
结构化数据用主键和约束表达规则。查询用户输入时请使用参数化接口，而非字符串拼接。
```sql
CREATE TABLE events (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  capacity INTEGER NOT NULL CHECK (capacity > 0)
);
SELECT id, title FROM events ORDER BY id DESC;
```

### 测试：先定义预期再实现
测试不能只检验「函数运行了」；要检查输入、输出和边界情况。
```js
import {test, expect} from 'vitest';
import {filterEvents} from './events.js';
test('没有命中时返回空数组', () => {
  expect(filterEvents([{title:'算法'}], '音乐')).toEqual([]);
});
```

## AI 配合学习：4 类提示词
### 导师模式 · 不代写
用途：适合学习新知识
> 我在学 Web 开发，有一点 C++ 基础。请用一个最小例子讲清楚「CSS Flexbox 主轴和交叉轴」，先让我预测结果，再给我一道能独立完成的练习。不要直接生成整页代码。

### 代码审查 · 指出证据
用途：适合自写代码后
> 请审查下面的 HTML/CSS/JS。按「真实错误 / 可访问性 / 响应式 / 可维护性」分类；只报告能指出代码位置和复现方式的问题。优先解释根因，不要直接大改。代码如下：
> [粘贴代码]

### 工程协作 · 限定范围
用途：适合已掌握的功能
> 你作为前端开发搭档：只修改活动列表的搜索交互，不重做页面样式。先说明将修改哪些文件和验收方案，再实现。完成后给出运行命令、测试结果和仍需我手动确认的项目。

### 测试设计 · 破坏正常路径
用途：适合验收 AI 生成代码
> 为这个功能设计测试用例，必须覆盖：正常、空数据、长文本、错误输入、网络失败、重复操作、手机布局。说明每个用例的操作步骤、预期结果以及如何知道它真的通过；不要凭空声称已运行。

**AI 提交的每次代码都要检查**：改了哪些文件；哪些命令真实执行；成功与失败用例；有没有假数据或假按钮；还有哪些步骤没验证。

## 阶段结业验收
### 共同基础结业（第 8 周）
- [ ] 独立编写包含导航、3 个内容区块和页脚的页面
- [ ] 手机、平板、桌面都没有明显布局错误
- [ ] 页面有搜索/筛选或收藏等真实 JS 交互
- [ ] 断网、空数据、异常输入有可理解的反馈
- [ ] GitHub 中有 README、提交记录、可访问的演示页面

### 前端结业（第 20 周）
- [ ] React / Vue 二选一，完成至少 3 个有导航关系的页面
- [ ] 正确处理 API 加载/失败/为空/成功四种状态
- [ ] 复用组件、适当使用 TypeScript 与清晰目录结构
- [ ] 有关键逻辑自动化测试和移动端手测证据
- [ ] 演示地址、源码、README 和 3 分钟演示齐全

### 全栈结业（第 24 周）
- [ ] 前端页面能调用自建真实 API，实现数据库 CRUD
- [ ] 普通用户与管理员权限由后端独立强制校验
- [ ] SQL 约束/参数化查询/会话安全实践可解释
- [ ] 测试覆盖越权、非法输入、网络异常、数据重启后保持
- [ ] 线上部署图、环境变量样例、备份/恢复和回滚说明齐全

## 技术选择 / 避坑
- 前端框架：React 或 Vue 二选一；懂 HTML/CSS/JS 后再学。
- 全栈后端：默认 JavaScript/TypeScript + Node.js/Express；熟悉 Python 可选 FastAPI。不要两条后端路线并行。
- 数据库：先学基本 SQL；个人本地项目 SQLite 足够；进一步多人部署学习 PostgreSQL。
- 第一次项目不要追求微服务、Kubernetes、复杂消息队列、自己写认证算法、酷炫但无意义的动画。
- GitHub Pages 是静态托管，不是运行数据库或后端进程的地方。
- 课表是经验建议；每周约 5–10 小时，按实际进度调整。

## 术语速查
- **HTML**：规定网页内容结构和语义的标记语言。
- **CSS**：控制网页的排版、布局、颜色、动画等显示效果。
- **JavaScript**：让网页响应用户操作、操作 DOM、发起请求的编程语言。
- **DOM**：浏览器把 HTML 解析成的可操作文档对象树。
- **HTTP**：浏览器与服务器交换请求和响应的协议。
- **API**：约定程序间如何请求数据/执行操作的接口。
- **JSON**：常见的文本数据交换格式；不是数据库。
- **前端框架**：帮助组织组件和 UI 状态的工具，例如 React、Vue。
- **Node.js**：在浏览器外运行 JavaScript 的运行时，可用于编写服务器。
- **数据库**：管理持久化数据及其查询、约束和事务的系统。
- **认证 Authentication**：确认请求者是谁，例如检查登录状态。
- **授权 Authorization**：决定已识别的用户能执行哪些操作。
- **CORS**：浏览器的跨源资源访问机制，不等价于鉴权。
- **Git**：跟踪代码版本和协作更改的版本控制系统。
- **CI**：提交代码后自动构建、静态检查和测试的流程。
- **SSR/SPA**：SSR 是服务端渲染，SPA 是单页应用；初学者先掌握静态页面/客户端渲染。

## 官方资料索引（已按用途分类）
- **共同基础**｜[MDN：Web 入门（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Getting_started)：环境、HTML/CSS/JS 第一页、发布第一个网站
- **共同基础**｜[MDN：Web 核心学习（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core)：结构化主教材；HTML、CSS、JS、无障碍、框架
- **共同基础**｜[The Odin Project：Foundations](https://www.theodinproject.com/paths/foundations/courses/foundations)：项目式练习；英文教材，建议与 MDN 搭配
- **JavaScript**｜[现代 JavaScript 教程（中文）](https://zh.javascript.info/)：从语法、对象、异步到浏览器 DOM，适合作为补充
- **共同基础**｜[MDN：HTTP 概述（中文）](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Guides/Overview)：理解请求、响应、状态码和客户端—服务器结构
- **质量**｜[MDN：Web 无障碍（中文）](https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core/Accessibility)：语义化、键盘操作、对比度、表单与替代文本
- **工具**｜[Pro Git（中文）](https://git-scm.com/book/zh/v2)：commit、分支、合并、冲突和协作
- **前端进阶**｜[Vite：入门指南](https://vite.dev/guide/)：现代前端开发服务器、构建命令和模板
- **前端进阶**｜[TypeScript：官方手册](https://www.typescriptlang.org/docs/handbook/intro)：类型、接口、联合类型、类型收窄
- **前端进阶**｜[React：Thinking in React](https://react.dev/learn/thinking-in-react)：组件拆分、状态与数据流
- **前端进阶**｜[Vue 3：官方中文指南](https://cn.vuejs.org/guide/introduction)：模板、响应式、组件与组合式 API
- **全栈进阶**｜[Node.js：官方学习文档](https://nodejs.org/learn/getting-started/introduction-to-nodejs)：服务器运行时、事件循环与文件/网络 I/O
- **全栈进阶**｜[Express：Hello World 与路由](https://expressjs.com/en/starter/hello-world/)：用 JavaScript 编写最简单的 HTTP API
- **全栈进阶**｜[FastAPI：官方中文教程](https://fastapi.tiangolo.com/zh/tutorial/)：Python 后端替代路线；与 Express 二选一
- **全栈进阶**｜[PostgreSQL：官方 SQL 教程](https://www.postgresql.org/docs/current/tutorial.html)：SQL、关系、查询与事务
- **安全**｜[OWASP Top 10（2025）](https://top10.owasp.org/2025/0x00_2025-Introduction/)：Web 安全基础；访问控制、注入、配置风险等
- **质量**｜[Vitest：官方入门](https://vitest.dev/guide/)：JS / TS 单元测试、断言与测试运行
- **质量**｜[Playwright：官方文档](https://playwright.dev/docs/intro)：浏览器端到端测试，模拟用户操作
- **部署**｜[GitHub Pages：发布教程](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)：静态网站上线；不能直接运行服务器或数据库
- **质量**｜[web.dev：Learn Performance](https://web.dev/learn/performance)：加载性能、图片优化、测量方式

---
教学使用建议：每周评审看可运行成果和调试证据，而不只是读过的文档页数。修改项目时先写预期，再动手和验收。
